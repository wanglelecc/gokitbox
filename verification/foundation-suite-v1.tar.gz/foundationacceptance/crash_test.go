package foundationacceptance_test

import (
	"context"
	"github.com/redis/go-redis/v9"
	"github.com/wanglelecc/gokitbox/taskqueue"
	"github.com/wanglelecc/gokitbox/worker/consumer"
	"os"
	"os/exec"
	"testing"
	"time"
)

func TestWorkerCrashHelper(t *testing.T) {
	addr := os.Getenv("FOUNDATION_CHILD_REDIS")
	if addr == "" {
		return
	}
	mode := os.Getenv("FOUNDATION_CHILD_MODE")
	c := redis.NewClient(&redis.Options{Addr: addr, ContextTimeoutEnabled: true, MaxRetries: -1})
	_, err := consumer.NewRedisConsumerWithContext([]*consumer.RedisConfig{{Addr: addr, Queue: "crash-source", ConsumerCount: 1, FailCount: 3}}, func(ctx context.Context, _ string, _ string, b []byte) (bool, error) {
		id := taskqueue.TaskID(ctx)
		if id == "" {
			return false, os.ErrInvalid
		}
		if err := c.Set(context.Background(), "entered:"+mode, id, 0).Err(); err != nil {
			return false, err
		}
		if mode == "crash" {
			<-ctx.Done()
			return false, ctx.Err()
		}
		return string(b) == "payload", nil
	}, consumer.RuntimeOptions{VisibilityTimeout: 300 * time.Millisecond, OperationTimeout: 50 * time.Millisecond, HandlerTimeout: 2 * time.Second}, nil)
	if err != nil {
		t.Fatal(err)
	}
	select {}
}
func TestDefaultWorkerRecoversKilledProcess(t *testing.T) {
	c := redisClient(t)
	ctx := context.Background()
	must(t, c.RPush(ctx, "crash-source", "payload").Err())
	start := func(mode string) *exec.Cmd {
		cmd := exec.Command(os.Args[0], "-test.run=^TestWorkerCrashHelper$", "-test.timeout=15s")
		cmd.Env = append(os.Environ(), "FOUNDATION_CHILD_REDIS="+c.Options().Addr, "FOUNDATION_CHILD_MODE="+mode)
		if err := cmd.Start(); err != nil {
			t.Fatal(err)
		}
		return cmd
	}
	wait := func(f func() bool) {
		t.Helper()
		deadline := time.Now().Add(6 * time.Second)
		for !f() {
			if time.Now().After(deadline) {
				t.Fatal("child progress timed out")
			}
			time.Sleep(10 * time.Millisecond)
		}
	}
	crashed := start("crash")
	t.Cleanup(func() { crashed.Process.Kill() })
	wait(func() bool { return c.Exists(ctx, "entered:crash").Val() == 1 })
	original := c.Get(ctx, "entered:crash").Val()
	must(t, crashed.Process.Kill())
	crashed.Wait()
	recovery := start("recover")
	defer func() { recovery.Process.Kill(); recovery.Wait() }()
	wait(func() bool { return c.Exists(ctx, "entered:recover").Val() == 1 })
	if c.Get(ctx, "entered:recover").Val() != original {
		t.Fatal("task identity changed after process crash")
	}
	q, err := taskqueue.New(c, "crash-source", "list", time.Second)
	must(t, err)
	wait(func() bool { s, err := q.Stats(ctx); return err == nil && s.Stored == 0 && s.Active == 0 })
}
