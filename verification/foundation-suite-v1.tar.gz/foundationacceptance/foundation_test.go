package foundationacceptance_test

import (
	"bytes"
	"context"
	"errors"
	"fmt"
	"github.com/redis/go-redis/v9"
	"github.com/smallnest/rpcx/protocol"
	"github.com/wanglelecc/gokitbox/event"
	"github.com/wanglelecc/gokitbox/redisdao"
	"github.com/wanglelecc/gokitbox/rpcxauth"
	"github.com/wanglelecc/gokitbox/taskqueue"
	u "github.com/wanglelecc/gokitbox/tools/uHTTP"
	"github.com/wanglelecc/gokitbox/tools/uHash"
	"github.com/wanglelecc/gokitbox/tools/uNo"
	"github.com/wanglelecc/gokitbox/tools/uSnowflake"
	"io"
	"net"
	"net/http"
	"net/http/httptest"
	"os/exec"
	"strconv"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func redisClient(t *testing.T) *redis.Client {
	t.Helper()
	binary, err := exec.LookPath("redis-server")
	if err != nil {
		t.Fatal("acceptance requires redis-server")
	}
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := l.Addr().(*net.TCPAddr).Port
	l.Close()
	cmd := exec.Command(binary, "--bind", "127.0.0.1", "--port", strconv.Itoa(port), "--save", "", "--appendonly", "no", "--dir", t.TempDir())
	if err = cmd.Start(); err != nil {
		t.Fatal(err)
	}
	c := redis.NewClient(&redis.Options{Addr: fmt.Sprintf("127.0.0.1:%d", port), ContextTimeoutEnabled: true, MaxRetries: -1})
	t.Cleanup(func() { c.Close(); cmd.Process.Kill(); cmd.Wait() })
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	for c.Ping(ctx).Err() != nil {
		select {
		case <-ctx.Done():
			t.Fatal(ctx.Err())
		case <-time.After(5 * time.Millisecond):
		}
	}
	return c
}
func must(t *testing.T, err error) {
	t.Helper()
	if err != nil {
		t.Fatal(err)
	}
}
func TestIDReservationsAcrossRolesAndRestart(t *testing.T) {
	c := redisClient(t)
	p := redisdao.NewRedisNodeProviderWithClient(c)
	ctx := context.Background()
	if _, err := uSnowflake.New(ctx, p, "project", "admin"); err == nil {
		t.Fatal("uninitialized pool accepted")
	}
	must(t, p.InitializePool(ctx, "project"))
	a, err := uSnowflake.New(ctx, p, "project", "admin")
	must(t, err)
	b, err := uSnowflake.New(ctx, p, "project", "worker")
	must(t, err)
	defer a.Close(ctx)
	defer b.Close(ctx)
	seen := sync.Map{}
	var wg sync.WaitGroup
	for _, g := range []*uSnowflake.Generator{a, b} {
		for i := 0; i < 4; i++ {
			wg.Add(1)
			go func(g *uSnowflake.Generator) {
				defer wg.Done()
				for j := 0; j < 1000; j++ {
					v, err := g.Next(ctx)
					if err != nil {
						t.Error(err)
						return
					}
					if _, duplicate := seen.LoadOrStore(v, true); duplicate {
						t.Error("duplicate", v)
					}
				}
			}(g)
		}
	}
	wg.Wait()
	must(t, a.Close(ctx))
	replacement, err := uSnowflake.New(ctx, p, "project", "api")
	must(t, err)
	defer replacement.Close(ctx)
	v, err := replacement.Next(ctx)
	must(t, err)
	if _, dup := seen.LoadOrStore(v, true); dup {
		t.Fatal("duplicate after node reuse")
	}
	if _, err = a.Next(ctx); err == nil {
		t.Fatal("closed generator issued id")
	}
}
func TestIDOwnershipLossAndCapacity(t *testing.T) {
	c := redisClient(t)
	p := redisdao.NewRedisNodeProviderWithClient(c)
	ctx := context.Background()
	must(t, p.InitializePool(ctx, "capacity"))
	key := "gokitbox:snowflake:v2:{capacity}"
	args := []interface{}{}
	for n := 0; n < 1024; n++ {
		args = append(args, fmt.Sprintf("until:%d", n), time.Now().Add(time.Hour).UnixMilli())
	}
	must(t, c.HSet(ctx, key, args...).Err())
	if _, err := p.Acquire(ctx, "capacity", "role"); err == nil {
		t.Fatal("capacity wrapped")
	}
	must(t, p.InitializePool(ctx, "loss"))
	lease, err := p.Acquire(ctx, "loss", "a")
	must(t, err)
	_, err = lease.Reserve(ctx)
	must(t, err)
	must(t, c.HSet(ctx, "gokitbox:snowflake:v2:{loss}", "owner:0", "other").Err())
	if _, err = lease.Reserve(ctx); err == nil {
		t.Fatal("lost owner renewed")
	}
	must(t, lease.Close(ctx))
	owner, err := c.HGet(ctx, "gokitbox:snowflake:v2:{loss}", "owner:0").Result()
	must(t, err)
	if owner != "other" {
		t.Fatal("old close removed new owner")
	}
}
func TestLeaseDoesNotDeleteNewOwner(t *testing.T) {
	c := redisClient(t)
	ctx := context.Background()
	a, err := redisdao.Acquire(ctx, c, "lock", 30*time.Millisecond)
	must(t, err)
	time.Sleep(40 * time.Millisecond)
	b, err := redisdao.Acquire(ctx, c, "lock", time.Second)
	must(t, err)
	if !errors.Is(a.Release(ctx), redisdao.ErrLeaseLost) {
		t.Fatal("lost owner not reported")
	}
	if _, err = redisdao.Acquire(ctx, c, "lock", time.Second); !errors.Is(err, redisdao.ErrLockHeld) {
		t.Fatal("new owner deleted")
	}
	must(t, b.Renew(ctx, time.Second))
	must(t, b.Release(ctx))
	must(t, b.Release(ctx))
	if _, err = redisdao.Acquire(ctx, c, "zero", 0); err == nil {
		t.Fatal("zero ttl accepted")
	}
}
func TestBusinessNumbersAndCanonicalSignatures(t *testing.T) {
	seen := map[string]bool{}
	for i := 0; i < 20000; i++ {
		id := uNo.GenOrderNo(1)
		if seen[id] || len(id) != 28 {
			t.Fatal("duplicate/format", id)
		}
		seen[id] = true
	}
	a := uHash.SignV2(map[string]string{"a": "1&b=2"}, "secret")
	b := uHash.SignV2(map[string]string{"a": "1", "b": "2"}, "secret")
	if a == b {
		t.Fatal("ambiguous signature")
	}
	func() {
		defer func() {
			if recover() == nil {
				t.Error("truncation allowed")
			}
		}()
		uNo.GenOrderNo(1, uNo.Option{Length: 18})
	}()
}
func TestRPCV2TamperReplayAndStoreFailure(t *testing.T) {
	c := redisClient(t)
	store := redisdao.ReplayStore{Client: c, Prefix: "replay"}
	ctx := context.Background()
	r := protocol.NewMessage()
	r.ServicePath = "Service"
	r.ServiceMethod = "Read"
	r.Payload = []byte("data")
	must(t, rpcxauth.SignRequest(r, "app", "secret", "domain"))
	r.Payload = []byte("tampered")
	if err := rpcxauth.Verify(ctx, r, "secret", "domain", time.Minute, store); err == nil {
		t.Fatal("tamper accepted")
	}
	r.Payload = []byte("data")
	var accepted atomic.Int32
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			if rpcxauth.Verify(ctx, r, "secret", "domain", time.Minute, store) == nil {
				accepted.Add(1)
			}
		}()
	}
	wg.Wait()
	if accepted.Load() != 1 {
		t.Fatal("replay accepted", accepted.Load())
	}
	must(t, rpcxauth.SignRequest(r, "app", "secret", "domain"))
	c.Close()
	if rpcxauth.Verify(ctx, r, "secret", "domain", time.Minute, store) == nil {
		t.Fatal("store failure opened auth")
	}
}
func TestEventSnapshotAndConcurrentMutation(t *testing.T) {
	d := event.NewEventDispatcher()
	var calls atomic.Int64
	var first *event.EventListener
	first = event.NewEventListener(func(e event.Event) { calls.Add(1); d.RemoveEventListener("x", first) })
	d.AddEventListener("x", first)
	d.AddEventListener("x", event.NewEventListener(func(event.Event) { calls.Add(1) }))
	d.DispatchEvent(event.NewEvent("x", nil))
	if calls.Load() != 2 {
		t.Fatal("reentrant snapshot failed")
	}
	var wg sync.WaitGroup
	for i := 0; i < 10; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			l := event.NewEventListener(func(event.Event) {})
			for j := 0; j < 100; j++ {
				d.AddEventListener("x", l)
				d.DispatchEvent(event.NewEvent("x", nil))
				d.RemoveEventListener("x", l)
			}
		}()
	}
	wg.Wait()
}
func TestHTTPReuseLimitsCancellationAndClose(t *testing.T) {
	var connections atomic.Int32
	s := httptest.NewUnstartedServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Path == "/large" {
			w.Write(bytes.Repeat([]byte("x"), 1025))
			return
		}
		if r.URL.Path == "/wait" {
			<-r.Context().Done()
			return
		}
		w.Write([]byte("ok"))
	}))
	s.Config.ConnState = func(_ net.Conn, state http.ConnState) {
		if state == http.StateNew {
			connections.Add(1)
		}
	}
	s.Start()
	defer s.Close()
	cfg := u.DefaultConfig()
	cfg.MaxResponseBytes = 1024
	c, err := u.NewClient(cfg)
	must(t, err)
	defer c.Close()
	for i := 0; i < 100; i++ {
		_, _, b, err := c.Do(context.Background(), "GET", s.URL, nil, nil)
		must(t, err)
		if string(b) != "ok" {
			t.Fatal(string(b))
		}
	}
	if connections.Load() > 2 {
		t.Fatal("no reuse", connections.Load())
	}
	if _, _, _, err = c.Do(context.Background(), "GET", s.URL+"/large", nil, nil); !errors.Is(err, u.ErrResponseTooLarge) {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Millisecond)
	defer cancel()
	if _, _, _, err = c.Do(ctx, "GET", s.URL+"/wait", nil, nil); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	must(t, c.Close())
	if _, _, _, err = c.Do(context.Background(), "GET", s.URL, nil, nil); !errors.Is(err, u.ErrClosed) {
		t.Fatal(err)
	}
}
func TestTaskCrashRecoveryLateAckAndSchedule(t *testing.T) {
	c := redisClient(t)
	q, err := taskqueue.New(c, "source", "list", 40*time.Millisecond)
	must(t, err)
	ctx := context.Background()
	must(t, q.Enqueue(ctx, taskqueue.Message{ID: "stable", Payload: []byte("hello")}, time.Time{}))
	if !errors.Is(q.Enqueue(ctx, taskqueue.Message{ID: "stable", Payload: []byte("changed")}, time.Time{}), taskqueue.ErrDuplicate) {
		t.Fatal("duplicate task replaced")
	}
	a, err := q.Claim(ctx)
	must(t, err)
	time.Sleep(55 * time.Millisecond)
	b, err := q.Claim(ctx)
	must(t, err)
	if a.ID != b.ID || b.Attempt != 2 || string(b.Payload) != "hello" {
		t.Fatalf("recovery %v %v", a, b)
	}
	if !errors.Is(q.Ack(ctx, a), taskqueue.ErrLeaseLost) {
		t.Fatal("stale ack deleted new owner")
	}
	must(t, q.Renew(ctx, b))
	must(t, q.Ack(ctx, b))
	if _, err = q.Claim(ctx); !errors.Is(err, taskqueue.ErrEmpty) {
		t.Fatal(err)
	}
	must(t, q.Enqueue(ctx, taskqueue.Message{ID: "later", Payload: []byte("later")}, time.Now().Add(80*time.Millisecond)))
	if _, err = q.Claim(ctx); !errors.Is(err, taskqueue.ErrEmpty) {
		t.Fatal("scheduled task too early", err)
	}
	time.Sleep(90 * time.Millisecond)
	m, err := q.Claim(ctx)
	must(t, err)
	must(t, q.Fail(ctx, m, ""))
	dead, err := q.DeadLetters(ctx, 0, -1)
	must(t, err)
	if len(dead) != 1 || dead[0].ID != "later" {
		t.Fatal(dead)
	}
	must(t, q.RequeueDead(ctx, "later"))
	m, err = q.Claim(ctx)
	must(t, err)
	must(t, q.Ack(ctx, m))
}
func TestRawListDelayAndEmptyPayload(t *testing.T) {
	c := redisClient(t)
	ctx := context.Background()
	for _, kind := range []string{"list", "delay"} {
		q, err := taskqueue.New(c, kind, kind, time.Second)
		must(t, err)
		if kind == "list" {
			must(t, c.RPush(ctx, kind, "").Err())
		} else {
			must(t, c.ZAdd(ctx, kind, redis.Z{Score: float64(time.Now().Unix()), Member: ""}).Err())
		}
		m, err := q.Claim(ctx)
		must(t, err)
		if len(m.Payload) != 0 {
			t.Fatal("empty payload corrupted")
		}
		must(t, q.Retry(ctx, m))
		m, err = q.Claim(ctx)
		must(t, err)
		must(t, q.Ack(ctx, m))
	}
}

var _ io.Reader

func TestIdenticalDelayDeadLettersKeepDistinctIDs(t *testing.T) {
	c := redisClient(t)
	ctx := context.Background()
	q, err := taskqueue.New(c, "source-delay", "delay", time.Second)
	must(t, err)
	for _, id := range []string{"job-a", "job-b"} {
		must(t, q.Enqueue(ctx, taskqueue.Message{ID: id, Payload: []byte("same")}, time.Time{}))
		m, err := q.Claim(ctx)
		must(t, err)
		must(t, q.Fail(ctx, m, "failure-delay"))
	}

	dead, err := taskqueue.New(c, "failure-delay", "delay", time.Second)
	must(t, err)
	seen := map[string]bool{}
	for i := 0; i < 2; i++ {
		m, err := dead.Claim(ctx)
		must(t, err)
		if string(m.Payload) != "same" {
			t.Fatal("wire envelope leaked into payload", string(m.Payload))
		}
		seen[m.ID] = true
		must(t, dead.Ack(ctx, m))
	}
	if !seen["job-a"] || !seen["job-b"] {
		t.Fatal(seen)
	}
}

func TestGeneratorStopsOnRenewalFailure(t *testing.T) {
	c := redisClient(t)
	ctx := context.Background()
	p := redisdao.NewRedisNodeProviderWithClient(c)
	must(t, p.InitializePool(ctx, "renewal-failure"))
	g, err := uSnowflake.New(ctx, p, "renewal-failure", "role")
	must(t, err)
	c.Close()
	wait, cancel := context.WithTimeout(ctx, 4*time.Second)
	defer cancel()
	if err = g.Wait(wait); !errors.Is(err, uSnowflake.ErrUnavailable) {
		t.Fatal("renewal failure not supervised", err)
	}
	if _, err = g.Next(ctx); err == nil {
		t.Fatal("generator continued without coordinator")
	}
	g.Close(ctx)
}
