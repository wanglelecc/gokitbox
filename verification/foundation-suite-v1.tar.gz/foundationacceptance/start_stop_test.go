package foundationacceptance_test

import (
	"context"
	"errors"
	"github.com/wanglelecc/gokitbox/bootstrap"
	"github.com/wanglelecc/gokitbox/httpserver"
	"github.com/wanglelecc/gokitbox/rpcxserver"
	"testing"
	"time"
)

type managedServer interface {
	Start(context.Context) error
	Stop(context.Context) error
	Wait() error
	AddBeforeServerStartFunc(...bootstrap.BeforeServerStartFunc)
}

func newManaged(t *testing.T, kind string) managedServer {
	if kind == "http" {
		o := httpserver.DefaultOptions()
		o.Addr = "127.0.0.1:0"
		s, err := httpserver.NewServerWithOptions(o)
		must(t, err)
		return s
	}
	o := rpcxserver.DefaultOptions()
	o.Port = "0"
	return rpcxserver.NewServerWithOptions(o)
}
func TestStartStopOwnershipBarrier(t *testing.T) {
	for _, kind := range []string{"http", "rpcx"} {
		t.Run(kind, func(t *testing.T) {
			s := newManaged(t, kind)
			entered, release := make(chan struct{}), make(chan struct{})
			s.AddBeforeServerStartFunc(func() error { close(entered); <-release; return nil })
			started := make(chan error, 1)
			go func() { started <- s.Start(context.Background()) }()
			<-entered
			ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
			defer cancel()
			if !errors.Is(s.Stop(ctx), context.DeadlineExceeded) {
				t.Fatal("incomplete startup hidden")
			}
			close(release)
			select {
			case err := <-started:
				if err == nil {
					t.Fatal("start succeeded after stop")
				}
			case <-time.After(time.Second):
				t.Fatal("startup stuck")
			}
			cleanup, stop := context.WithTimeout(context.Background(), time.Second)
			defer stop()
			s.Stop(cleanup)
			if err := s.Start(context.Background()); err == nil {
				t.Fatal("closed server resurrected")
			}
		})
	}
}
func TestStopBeforeStartIsTerminal(t *testing.T) {
	for _, kind := range []string{"http", "rpcx"} {
		s := newManaged(t, kind)
		must(t, s.Stop(context.Background()))
		if s.Start(context.Background()) == nil {
			t.Fatal("close-before-start opened", kind)
		}
	}
}

func TestStartupPanicReturnsErrorAndCanBeCleaned(t *testing.T) {
	for _, kind := range []string{"http", "rpcx"} {
		s := newManaged(t, kind)
		s.AddBeforeServerStartFunc(func() error { panic("secret startup value") })
		if err := s.Start(context.Background()); err == nil {
			t.Fatal("panic hidden")
		}
		ctx, cancel := context.WithTimeout(context.Background(), time.Second)
		s.Stop(ctx)
		cancel()
		if err := s.Wait(); err == nil {
			t.Fatal("startup failure hidden from Wait")
		}
	}
}
