package foundationacceptance_test

import (
	"bytes"
	"compress/gzip"
	"context"
	"encoding/binary"
	"github.com/gin-gonic/gin"
	"github.com/smallnest/rpcx/client"
	"github.com/smallnest/rpcx/protocol"
	m "github.com/wanglelecc/gokitbox/httpserver/middleware"
	"github.com/wanglelecc/gokitbox/logger"
	"github.com/wanglelecc/gokitbox/redisdao"
	"github.com/wanglelecc/gokitbox/rpcxauth"
	"github.com/wanglelecc/gokitbox/rpcxclient"
	"github.com/wanglelecc/gokitbox/rpcxserver"
	u "github.com/wanglelecc/gokitbox/tools/uHTTP"
	"net/http/httptest"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"
)

type WireArgs struct{ Value int }
type WireReply struct{ Value int }
type WireService struct{}

func (*WireService) Double(ctx context.Context, args *WireArgs, reply *WireReply) error {
	reply.Value = args.Value * 2
	return nil
}
func TestRPCV2OverActualSDKWire(t *testing.T) {
	rdb := redisClient(t)
	o := rpcxserver.DefaultOptions()
	o.Port = "0"
	s := rpcxserver.NewServerWithOptions(o)
	s.AddBeforeServerStartFunc(s.InitRpcxAuthV2(map[string]string{"wire-app": "wire-secret"}, rpcxserver.AuthOptions{ReplayStore: redisdao.ReplayStore{Client: rdb, Prefix: "wire"}}), s.RegisterServiceWithName("Math", &WireService{}, ""))
	must(t, s.Start(context.Background()))
	defer s.Stop(context.Background())
	discovery, err := client.NewPeer2PeerDiscovery("tcp@"+s.Server().Address().String(), "")
	must(t, err)
	option := client.DefaultOption
	option.SerializeType = protocol.JSON
	option.CompressType = protocol.Gzip
	c := client.NewXClient("Math", client.Failfast, client.RandomSelect, discovery, option)
	defer c.Close()
	wrap, err := rpcxclient.NewDefaultWrapWithOptions("Math", rpcxclient.WrapOptions{AppId: "wire-app", AppKey: "wire-secret", CallTimeout: time.Second})
	must(t, err)
	var wg sync.WaitGroup
	for n := 0; n < 20; n++ {
		wg.Add(1)
		go func(n int) {
			defer wg.Done()
			reply := new(WireReply)
			if err := wrap.WrapCall(c, context.Background(), "Double", &WireArgs{n}, reply); err != nil {
				t.Error(err)
				return
			}
			if reply.Value != 2*n {
				t.Error("wrong response", reply)
			}
		}(n)
	}
	wg.Wait()
}
func TestRPCFrameAndInflationBounds(t *testing.T) {
	message := protocol.NewMessage()
	data := message.Encode()
	binary.BigEndian.PutUint32(data[12:16], uint32(rpcxauth.MaxFrameBytes+1))
	decoded := protocol.NewMessage()
	if err := decoded.Decode(bytes.NewReader(data)); err == nil {
		t.Fatal("oversize frame accepted")
	}
	var compressed bytes.Buffer
	writer := gzip.NewWriter(&compressed)
	writer.Write(bytes.Repeat([]byte("x"), rpcxauth.MaxFrameBytes+1))
	writer.Close()
	if _, err := protocol.Compressors[protocol.Gzip].Unzip(compressed.Bytes()); err == nil {
		t.Fatal("gzip inflation exceeded bound")
	}
}
func TestLogsNeverContainCredentials(t *testing.T) {
	cfg := logger.NewConfig()
	cfg.Level = "DEBUG"
	cfg.FileName = filepath.Join(t.TempDir(), "log.json")
	must(t, logger.Initialize(cfg))
	gin.SetMode(gin.TestMode)
	router := gin.New()
	router.Use(m.Recovery(), m.Logger(m.CheckCode0))
	router.POST("/panic", func(c *gin.Context) { panic("secret-panic-value") })
	router.POST("/login", func(c *gin.Context) { c.JSON(200, gin.H{"code": 1, "token": "secret-response"}) })
	for _, path := range []string{"/panic", "/login"} {
		req := httptest.NewRequest("POST", path+"?token=secret-query", strings.NewReader(`{"password":"secret-password"}`))
		req.Header.Set("Authorization", "Bearer secret-authorization")
		req.Header.Set("Cookie", "session=secret-cookie")
		router.ServeHTTP(httptest.NewRecorder(), req)
	}
	logger.Sync()
	b, err := os.ReadFile(cfg.FileName)
	must(t, err)
	for _, secret := range []string{"secret-panic-value", "secret-response", "secret-query", "secret-password", "secret-authorization", "secret-cookie"} {
		if bytes.Contains(b, []byte(secret)) {
			t.Errorf("secret logged: %s", secret)
		}
	}
	if !bytes.Contains(b, []byte("http application failure")) {
		t.Fatal("error classification lost")
	}
}
func TestStreamingUploadLimitsAndCancellation(t *testing.T) {
	path := filepath.Join(t.TempDir(), "file.bin")
	must(t, os.WriteFile(path, bytes.Repeat([]byte("x"), 1<<20), 0600))
	cfg := u.DefaultConfig()
	cfg.MaxUploadBytes = 1024
	c, err := u.NewClient(cfg)
	must(t, err)
	defer c.Close()
	if _, _, _, err = c.Upload(context.Background(), "http://127.0.0.1:1", nil, map[string]string{"file": path}, nil); err != u.ErrUploadTooLarge {
		t.Fatal(err)
	}
	server := httptest.NewServer(nil)
	defer server.Close()
	cfg.MaxUploadBytes = 2 << 20
	client, err := u.NewClient(cfg)
	must(t, err)
	defer client.Close()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	if _, _, _, err = client.Upload(ctx, server.URL, nil, map[string]string{"file": path}, nil); err == nil {
		t.Fatal("cancelled upload succeeded")
	}
}

func TestConcurrentLoggingAndReconfigure(t *testing.T) {
	dir := t.TempDir()
	var wg sync.WaitGroup
	for n := 0; n < 4; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 100; i++ {
				logger.Ix(context.Background(), "race", "event")
				logger.SetName("foundation")
			}
		}()
	}
	for i := 0; i < 10; i++ {
		cfg := logger.NewConfig()
		cfg.FileName = filepath.Join(dir, "race.log")
		must(t, logger.Initialize(cfg))
	}
	wg.Wait()
	must(t, logger.Close())
	logger.Ix(context.Background(), "race", "late event")
}
