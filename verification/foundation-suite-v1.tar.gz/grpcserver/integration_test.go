package grpcserver_test

import (
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/pem"
	"errors"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"testing"
	"time"

	"github.com/wanglelecc/gokitbox/grpcclient"
	"github.com/wanglelecc/gokitbox/grpcserver"
	"google.golang.org/grpc"
	"google.golang.org/grpc/codes"
	pb "google.golang.org/grpc/health/grpc_health_v1"
	"google.golang.org/grpc/metadata"
	"google.golang.org/grpc/status"
)

type service struct {
	pb.UnimplementedHealthServer
	entered, release chan struct{}
}

func (s *service) Check(ctx context.Context, r *pb.HealthCheckRequest) (*pb.HealthCheckResponse, error) {
	switch r.Service {
	case "panic":
		panic("private secret")
	case "error":
		return nil, errors.New("private secret")
	case "status":
		return nil, status.Error(codes.NotFound, "missing")
	case "deadline":
		<-ctx.Done()
		return nil, ctx.Err()
	case "blocked":
		close(s.entered)
		<-s.release
	case "metadata":
		md, _ := metadata.FromIncomingContext(ctx)
		if md.Get("x-test")[0] != "override" {
			return nil, errors.New("metadata lost")
		}
	}
	return &pb.HealthCheckResponse{Status: pb.HealthCheckResponse_SERVING}, nil
}
func (s *service) Watch(_ *pb.HealthCheckRequest, stream pb.Health_WatchServer) error {
	if err := stream.Send(&pb.HealthCheckResponse{Status: pb.HealthCheckResponse_SERVING}); err != nil {
		return err
	}
	select {
	case <-time.After(150 * time.Millisecond):
		return stream.Send(&pb.HealthCheckResponse{Status: pb.HealthCheckResponse_NOT_SERVING})
	case <-stream.Context().Done():
		return stream.Context().Err()
	}
}
func options() grpcserver.Options {
	o := grpcserver.DefaultOptions()
	o.Addr = "127.0.0.1:0"
	o.Health = false
	o.LogFunc = func(context.Context, string, codes.Code, time.Duration) {}
	return o
}
func start(t *testing.T, o grpcserver.Options, impl pb.HealthServer) *grpcserver.Server {
	t.Helper()
	s, err := grpcserver.NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.Register(func(r grpc.ServiceRegistrar) { pb.RegisterHealthServer(r, impl) }); err != nil {
		t.Fatal(err)
	}
	if err = s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { s.Stop(context.Background()); s.Wait() })
	return s
}
func client(t *testing.T, s *grpcserver.Server, change func(*grpcclient.Options)) pb.HealthClient {
	t.Helper()
	o := grpcclient.DefaultOptions()
	o.Target = s.Addr().String()
	o.Insecure = true
	if change != nil {
		change(&o)
	}
	c, err := grpcclient.NewClientWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { c.Close(); c.Close() })
	return pb.NewHealthClient(c.Conn())
}
func TestUnaryAuthErrorsMetadataDeadline(t *testing.T) {
	o := options()
	o.BearerToken = "token"
	s := start(t, o, &service{})
	bad := client(t, s, nil)
	_, err := bad.Check(context.Background(), &pb.HealthCheckRequest{})
	if status.Code(err) != codes.Unauthenticated {
		t.Fatal(err)
	}
	c := client(t, s, func(o *grpcclient.Options) {
		o.BearerToken = "token"
		o.Metadata = map[string]string{"x-test": "default"}
		o.CallTimeout = 80 * time.Millisecond
	})
	for _, tc := range []struct {
		name string
		code codes.Code
	}{{"ok", codes.OK}, {"panic", codes.Internal}, {"error", codes.Internal}, {"status", codes.NotFound}, {"deadline", codes.DeadlineExceeded}} {
		_, err := c.Check(context.Background(), &pb.HealthCheckRequest{Service: tc.name})
		if status.Code(err) != tc.code {
			t.Fatalf("%s: %v", tc.name, err)
		}
		if err != nil && strings.Contains(err.Error(), "private secret") {
			t.Fatal("secret leaked")
		}
	}
	ctx := metadata.NewOutgoingContext(context.Background(), metadata.Pairs("x-test", "override"))
	if _, err := c.Check(ctx, &pb.HealthCheckRequest{Service: "metadata"}); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Millisecond)
	defer cancel()
	before := time.Now()
	_, err = c.Check(ctx, &pb.HealthCheckRequest{Service: "deadline"})
	if status.Code(err) != codes.DeadlineExceeded || time.Since(before) > 70*time.Millisecond {
		t.Fatal(err)
	}
	stream, err := bad.Watch(context.Background(), &pb.HealthCheckRequest{})
	if err == nil {
		_, err = stream.Recv()
	}
	if status.Code(err) != codes.Unauthenticated {
		t.Fatal(err)
	}
	stream, err = c.Watch(context.Background(), &pb.HealthCheckRequest{})
	if err != nil {
		t.Fatal(err)
	}
	if _, err = stream.Recv(); err != nil {
		t.Fatal(err)
	}
	if _, err = stream.Recv(); err != nil {
		t.Fatalf("unary timeout incorrectly applied to stream: %v", err)
	}
}
func TestShutdownBoundedAndIdempotent(t *testing.T) {
	impl := &service{entered: make(chan struct{}), release: make(chan struct{})}
	o := options()
	o.ShutdownTimeout = 40 * time.Millisecond
	s := start(t, o, impl)
	c := client(t, s, nil)
	done := make(chan struct{})
	go func() { c.Check(context.Background(), &pb.HealthCheckRequest{Service: "blocked"}); close(done) }()
	<-impl.entered
	before := time.Now()
	err := s.Stop(context.Background())
	if !errors.Is(err, context.DeadlineExceeded) || time.Since(before) > 500*time.Millisecond {
		t.Fatalf("shutdown: %v", err)
	}
	close(impl.release)
	<-done
	var wg sync.WaitGroup
	for i := 0; i < 8; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); s.Stop(context.Background()) }()
	}
	wg.Wait()
	if err = s.Start(context.Background()); err == nil {
		t.Fatal("restarted")
	}
}
func TestLifecycleAndRegistrationFailures(t *testing.T) {
	s, _ := grpcserver.NewServerWithOptions(options())
	if s.Wait() == nil {
		t.Fatal("wait before start")
	}
	if err := s.Stop(context.Background()); err != nil {
		t.Fatal(err)
	}
	if s.Start(context.Background()) == nil {
		t.Fatal("start after stop")
	}
	s, _ = grpcserver.NewServerWithOptions(options())
	fn := func(r grpc.ServiceRegistrar) { pb.RegisterHealthServer(r, &service{}) }
	if err := s.Register(fn); err != nil {
		t.Fatal(err)
	}
	if s.Register(fn) == nil {
		t.Fatal("duplicate accepted")
	}
	if s.Register(func(r grpc.ServiceRegistrar) { r.RegisterService(&pb.Health_ServiceDesc, struct{}{}) }) == nil {
		t.Fatal("bad impl accepted")
	}
	if s.Register(func(grpc.ServiceRegistrar) { panic("secret") }) == nil {
		t.Fatal("panic not mapped")
	}
	l, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer l.Close()
	o := options()
	o.Addr = l.Addr().String()
	s, _ = grpcserver.NewServerWithOptions(o)
	if s.Start(context.Background()) == nil {
		t.Fatal("bind accepted")
	}
	s.Stop(context.Background())
	if s.Wait() == nil {
		t.Fatal("lost startup error")
	}
	o = options()
	o.TLS = grpcserver.TLSOptions{Enabled: true, CertFile: "missing", KeyFile: "missing"}
	s, _ = grpcserver.NewServerWithOptions(o)
	if s.Start(context.Background()) == nil {
		t.Fatal("bad TLS")
	}
	s.Stop(context.Background())
}
func TestHealthAndErrorMapper(t *testing.T) {
	o := grpcserver.DefaultOptions()
	o.Addr = "127.0.0.1:0"
	s, err := grpcserver.NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	if err = s.Register(func(r grpc.ServiceRegistrar) { pb.RegisterHealthServer(r, &service{}) }); err == nil {
		t.Fatal("reserved name accepted")
	}
	if err = s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	defer s.Stop(context.Background())
	c := client(t, s, nil)
	reply, err := c.Check(context.Background(), &pb.HealthCheckRequest{})
	if err != nil || reply.Status != pb.HealthCheckResponse_SERVING {
		t.Fatal(reply, err)
	}
	s.SetServing(false)
	reply, err = c.Check(context.Background(), &pb.HealthCheckRequest{})
	if err != nil || reply.Status != pb.HealthCheckResponse_NOT_SERVING {
		t.Fatal(reply, err)
	}
	o = options()
	o.ErrorMapper = func(error) error { return status.Error(codes.FailedPrecondition, "mapped") }
	s = start(t, o, &service{})
	c = client(t, s, nil)
	_, err = c.Check(context.Background(), &pb.HealthCheckRequest{Service: "error"})
	if status.Code(err) != codes.FailedPrecondition {
		t.Fatal(err)
	}
}
func certificate(t *testing.T) (string, string, string, string, string) {
	t.Helper()
	dir := t.TempDir()
	pub, key, _ := ed25519.GenerateKey(rand.Reader)
	ca := &x509.Certificate{SerialNumber: big.NewInt(1), Subject: pkix.Name{CommonName: "test CA"}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().Add(time.Hour), IsCA: true, BasicConstraintsValid: true, KeyUsage: x509.KeyUsageCertSign}
	der, err := x509.CreateCertificate(rand.Reader, ca, ca, pub, key)
	if err != nil {
		t.Fatal(err)
	}
	write := func(name, kind string, data []byte) string {
		p := filepath.Join(dir, name)
		if err := os.WriteFile(p, pem.EncodeToMemory(&pem.Block{Type: kind, Bytes: data}), 0600); err != nil {
			t.Fatal(err)
		}
		return p
	}
	caFile := write("ca.pem", "CERTIFICATE", der)
	issue := func(name string, serial int64, usage x509.ExtKeyUsage) (string, string) {
		pub, k, _ := ed25519.GenerateKey(rand.Reader)
		cert := &x509.Certificate{SerialNumber: big.NewInt(serial), Subject: pkix.Name{CommonName: name}, DNSNames: []string{"localhost"}, NotBefore: ca.NotBefore, NotAfter: ca.NotAfter, KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{usage}}
		der, err := x509.CreateCertificate(rand.Reader, cert, ca, pub, key)
		if err != nil {
			t.Fatal(err)
		}
		priv, _ := x509.MarshalPKCS8PrivateKey(k)
		return write(name+".pem", "CERTIFICATE", der), write(name+".key", "PRIVATE KEY", priv)
	}
	server, serverKey := issue("server", 2, x509.ExtKeyUsageServerAuth)
	client, clientKey := issue("client", 3, x509.ExtKeyUsageClientAuth)
	return caFile, server, serverKey, client, clientKey
}
func TestTLSAndMutualTLS(t *testing.T) {
	ca, cert, key, cc, ck := certificate(t)
	for _, mutual := range []bool{false, true} {
		t.Run(map[bool]string{false: "TLS", true: "mTLS"}[mutual], func(t *testing.T) {
			o := options()
			o.TLS = grpcserver.TLSOptions{Enabled: true, CertFile: cert, KeyFile: key}
			if mutual {
				o.TLS.RequireClientCert = true
				o.TLS.ClientCAFile = ca
			}
			s := start(t, o, &service{})
			configure := func(o *grpcclient.Options) {
				o.Insecure = false
				o.CallTimeout = 300 * time.Millisecond
				o.TLS = grpcclient.TLSOptions{CAFile: ca, ServerName: "localhost"}
				if mutual {
					o.TLS.CertFile = cc
					o.TLS.KeyFile = ck
				}
			}
			c := client(t, s, configure)
			if _, err := c.Check(context.Background(), &pb.HealthCheckRequest{}); err != nil {
				t.Fatal(err)
			}
			bad := client(t, s, func(o *grpcclient.Options) { configure(o); o.TLS.ServerName = "wrong" })
			if _, err := bad.Check(context.Background(), &pb.HealthCheckRequest{}); err == nil {
				t.Fatal("wrong name accepted")
			}
			if mutual {
				bad = client(t, s, func(o *grpcclient.Options) { configure(o); o.TLS.CertFile = ""; o.TLS.KeyFile = "" })
				if _, err := bad.Check(context.Background(), &pb.HealthCheckRequest{}); err == nil {
					t.Fatal("missing client cert accepted")
				}
			}
		})
	}
}

func TestConcurrentStartStop(t *testing.T) {
	for i := 0; i < 30; i++ {
		s, err := grpcserver.NewServerWithOptions(options())
		if err != nil {
			t.Fatal(err)
		}
		started := make(chan struct{})
		go func() { s.Start(context.Background()); close(started) }()
		if err = s.Stop(context.Background()); err != nil {
			t.Fatal(err)
		}
		<-started
		if err = s.Register(func(grpc.ServiceRegistrar) {}); err == nil {
			t.Fatal("registration after stop")
		}
	}
}
func TestStreamRecoveryAndAuthenticationHook(t *testing.T) {
	o := options()
	o.AuthFunc = func(_ context.Context, method string) error {
		if strings.HasSuffix(method, "/Watch") {
			panic("secret")
		}
		return status.Error(codes.PermissionDenied, "denied")
	}
	s := start(t, o, &service{})
	c := client(t, s, nil)
	_, err := c.Check(context.Background(), &pb.HealthCheckRequest{})
	if status.Code(err) != codes.PermissionDenied {
		t.Fatal(err)
	}
	stream, err := c.Watch(context.Background(), &pb.HealthCheckRequest{})
	if err == nil {
		_, err = stream.Recv()
	}
	if status.Code(err) != codes.Internal || strings.Contains(err.Error(), "secret") {
		t.Fatal(err)
	}
}
func TestTLSClientInitializationError(t *testing.T) {
	o := grpcclient.DefaultOptions()
	o.Target = "localhost:1234"
	o.TLS.CAFile = "missing"
	if c, err := grpcclient.NewClientWithOptions(o); err == nil {
		c.Close()
		t.Fatal("missing CA accepted")
	}
	o.Insecure = true
	if c, err := grpcclient.NewClientWithOptions(o); err == nil {
		c.Close()
		t.Fatal("mixed security options accepted")
	}
}
