package httpserver

import (
	"context"
	"errors"
	"github.com/gin-gonic/gin"
	"net"
	"net/http"
	"testing"
	"time"
)

func TestExternalLifecycle(t *testing.T) {
	o := DefaultOptions()
	o.Addr = "127.0.0.1:0"
	o.Mode = "test"
	s, err := NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	s.GinEngine().GET("/ready", func(c *gin.Context) { c.Status(http.StatusNoContent) })
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := s.Start(ctx); err != nil {
		t.Fatal(err)
	}
	cancel() // startup context does not own runtime
	response, err := http.Get("http://" + s.runListener.Addr().String() + "/ready")
	if err != nil {
		t.Fatal(err)
	}
	response.Body.Close()
	if response.StatusCode != http.StatusNoContent {
		t.Fatal(response.Status)
	}
	stopCtx, stop := context.WithTimeout(context.Background(), time.Second)
	defer stop()
	if err := s.Stop(stopCtx); err != nil {
		t.Fatal(err)
	}
	if err := s.Wait(); err != nil {
		t.Fatal(err)
	}
	if err := s.Start(context.Background()); err == nil {
		t.Fatal("server restarted")
	}
}
func TestBindAndServeErrors(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	o := DefaultOptions()
	o.Addr = ln.Addr().String()
	o.Mode = "test"
	s, err := NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	if err := s.Start(context.Background()); err == nil {
		t.Fatal("bind error hidden")
	}
	if err := s.Stop(context.Background()); err != nil {
		t.Fatal(err)
	}
	o.Addr = "127.0.0.1:0"
	s, err = NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	if err := s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	s.runListener.Close()
	if err := s.Wait(); err == nil || !errors.Is(err, net.ErrClosed) {
		t.Fatalf("runtime failure hidden: %v", err)
	}
}

func TestStopRespectsConfiguredTimeout(t *testing.T) {
	o := DefaultOptions()
	o.Addr = "127.0.0.1:0"
	o.Mode = "test"
	o.ShutdownTimeout = "20ms"
	s, err := NewServerWithOptions(o)
	if err != nil {
		t.Fatal(err)
	}
	entered := make(chan struct{})
	release := make(chan struct{})
	s.GinEngine().GET("/blocked", func(c *gin.Context) { close(entered); <-release; c.Status(http.StatusNoContent) })
	if err := s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	requestDone := make(chan struct{})
	go func() {
		defer close(requestDone)
		response, err := http.Get("http://" + s.runListener.Addr().String() + "/blocked")
		if err == nil {
			response.Body.Close()
		}
	}()
	<-entered
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	err = s.Stop(ctx)
	close(release)
	<-requestDone
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("configured shutdown timeout ignored: %v", err)
	}
}
