package producer

import (
	"context"
	"errors"
	"net"
	"os/exec"
	"strconv"
	"testing"
	"time"

	native "github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"github.com/redis/go-redis/v9"
	"github.com/wanglelecc/gokitbox/producer/common"
	"github.com/wanglelecc/gokitbox/producer/kafka"
	"github.com/wanglelecc/gokitbox/producer/meta"
)

func TestRegressionProxyBlockedTypedAdmissionCloses(t *testing.T) {
	c, err := native.NewMockCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	if err = c.SetBrokerDown(1); err != nil {
		t.Fatal(err)
	}
	o := kafka.DefaultOptions()
	o.Brokers = []string{c.BootstrapServers()}
	o.BufferLimit = 0
	o.Timeout = 10 * time.Second
	m, err := New(Options{KafkaEnabled: true, Kafka: o})
	if err != nil {
		t.Fatal(err)
	}
	if err = m.Kafka("topic", []byte("first")); err != nil {
		t.Fatal(err)
	}
	entered := make(chan struct{})
	result := make(chan error, 1)
	go func() { close(entered); result <- m.Kafka("topic", []byte("blocked")) }()
	<-entered
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Millisecond)
	defer cancel()
	if err = m.CloseContext(ctx); err == nil {
		t.Fatal("unknown message hidden")
	}
	select {
	case err = <-result:
		if !errors.Is(err, ErrProducerClosed) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("admission deadlocked")
	}
	ctx2, stop := context.WithTimeout(context.Background(), 2*time.Second)
	defer stop()
	if err = m.Wait(ctx2); err == nil || errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("resource completion missing: %v", err)
	}
	if s := m.Snapshot(); s.Pending != 0 || s.Failed != 1 {
		t.Fatalf("%+v", s)
	}
}
func TestRegressionInstanceIsolationAndGray(t *testing.T) {
	var managers []*ProxyManager
	var clusters []*native.MockCluster
	defer func() {
		for _, m := range managers {
			m.Close()
		}
		for _, c := range clusters {
			c.Close()
		}
	}()
	for i := 0; i < 2; i++ {
		c, err := native.NewMockCluster(1)
		if err != nil {
			t.Fatal(err)
		}
		clusters = append(clusters, c)
		o := kafka.DefaultOptions()
		o.Brokers = []string{c.BootstrapServers()}
		m, err := New(Options{KafkaEnabled: true, Kafka: o, GrayMode: i == 1})
		if err != nil {
			t.Fatal(err)
		}
		managers = append(managers, m)
		o.Brokers[0] = "must-not-change"
		if err = m.Kafka("isolation", []byte(strconv.Itoa(i)), "key with spaces"); err != nil {
			t.Fatal(err)
		}
	}
	for i, m := range managers {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		err := m.CloseContext(ctx)
		cancel()
		if err != nil {
			t.Fatal(err)
		}
		topic := "isolation"
		if i == 1 {
			topic += "_gray"
		}
		consumer, err := native.NewConsumer(&native.ConfigMap{"bootstrap.servers": clusters[i].BootstrapServers(), "group.id": "isolated", "enable.auto.commit": false})
		if err != nil {
			t.Fatal(err)
		}
		if err = consumer.Assign([]native.TopicPartition{{Topic: &topic, Partition: 0, Offset: native.OffsetBeginning}}); err != nil {
			t.Fatal(err)
		}
		msg, err := consumer.ReadMessage(5 * time.Second)
		consumer.Close()
		if err != nil || msg == nil || string(msg.Value) != strconv.Itoa(i) || string(msg.Key) != "key with spaces" {
			t.Fatalf("wrong instance: %v %v", msg, err)
		}
	}
}
func TestRegressionDefaultStartRetryAndCloseBeforeStart(t *testing.T) {
	stdMu.Lock()
	savedStd, savedClosed := std, defaultClosed
	std = nil
	defaultClosed = false
	stdMu.Unlock()
	optionsMu.Lock()
	savedOpts, savedStarted := configuredOptions, started
	configuredOptions = &Options{KafkaEnabled: true, Kafka: kafka.DefaultOptions()}
	started = false
	optionsMu.Unlock()
	defer func() {
		CloseContext(context.Background())
		stdMu.Lock()
		std, defaultClosed = savedStd, savedClosed
		stdMu.Unlock()
		optionsMu.Lock()
		configuredOptions, started = savedOpts, savedStarted
		optionsMu.Unlock()
	}()
	if err := Start(); err == nil {
		t.Fatal("invalid configuration accepted")
	}
	optionsMu.Lock()
	configuredOptions = &Options{}
	optionsMu.Unlock()
	if err := Start(); err != nil {
		t.Fatal("failed init poisoned singleton", err)
	}
	if err := CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := Start(); !errors.Is(err, ErrProducerClosed) {
		t.Fatal(err)
	}
	stdMu.Lock()
	std = nil
	stdMu.Unlock()
	if err := CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := Start(); !errors.Is(err, ErrProducerClosed) {
		t.Fatal("close before start reopened", err)
	}
}
func TestRegressionFactoryPanicRollsBack(t *testing.T) {
	initLock.Lock()
	saved := initMap
	initMap = map[string]InitP{}
	initLock.Unlock()
	defer func() { initLock.Lock(); initMap = saved; initLock.Unlock() }()
	AddMQ("panic", func(chan struct{}, chan<- []byte) common.MQ { panic("injected factory") })
	o := kafka.DefaultOptions()
	o.Brokers = []string{"127.0.0.1:1"}
	if m, err := New(Options{KafkaEnabled: true, Kafka: o}); err == nil || m != nil {
		t.Fatalf("partial manager escaped: %v %v", m, err)
	}
}
func TestRegressionRedisHelpersIndependentOfKafka(t *testing.T) {
	binary, err := exec.LookPath("redis-server")
	if err != nil {
		t.Skip("redis-server unavailable")
	}
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	port := listener.Addr().(*net.TCPAddr).Port
	listener.Close()
	cmd := exec.Command(binary, "--bind", "127.0.0.1", "--port", strconv.Itoa(port), "--save", "", "--appendonly", "no", "--dir", t.TempDir())
	if err = cmd.Start(); err != nil {
		t.Fatal(err)
	}
	defer func() { cmd.Process.Kill(); cmd.Wait() }()
	client := redis.NewClient(&redis.Options{Addr: net.JoinHostPort("127.0.0.1", strconv.Itoa(port)), MaxRetries: -1})
	defer client.Close()
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()
	for client.Ping(ctx).Err() != nil {
		select {
		case <-ctx.Done():
			t.Fatal(ctx.Err())
		case <-time.After(10 * time.Millisecond):
		}
	}
	stdMu.Lock()
	savedStd, savedClosed := std, defaultClosed
	std = nil
	defaultClosed = true
	stdMu.Unlock()
	defer func() { stdMu.Lock(); std, defaultClosed = savedStd, savedClosed; stdMu.Unlock() }()
	if err = Redis(ctx, client, "queue", []byte("body")); err != nil {
		t.Fatal(err)
	}
	if err = Delay(ctx, client, "delay", []byte("body"), 123); err != nil {
		t.Fatal(err)
	}
	if s, err := client.LPop(ctx, "queue").Result(); err != nil || s != "body" {
		t.Fatal(s, err)
	}
	if score, err := client.ZScore(ctx, "delay", "body").Result(); err != nil || score != 123 {
		t.Fatal(score, err)
	}
	stdMu.Lock()
	initialized := std != nil
	stdMu.Unlock()
	if initialized {
		t.Fatal("Redis initialized Kafka")
	}
	cancel()
	if err = Redis(ctx, client, "queue", nil); !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
}

func TestRegressionLegacyNilPayloadAndEmptyKey(t *testing.T) {
	q := &reviewMQ{input: make(chan []byte, 1)}
	m := &ProxyManager{mqMap: map[string]common.MQ{meta.Kafka: q}, stopping: make(chan struct{})}
	if err := m.Kafka("topic", nil, ""); err != nil {
		t.Fatal(err)
	}
	value, err := common.Decode(<-q.input)
	if err != nil || value.Value == nil || len(value.Value) != 0 || value.Key == nil || len(value.Key) != 0 {
		t.Fatalf("nil/empty semantics changed: %#v %v", value, err)
	}
}

type asyncRollbackMQ struct{ quit chan struct{} }

func (q *asyncRollbackMQ) Input() chan<- []byte { return nil }
func (q *asyncRollbackMQ) SetFailMode()         {}
func (q *asyncRollbackMQ) Close()               { go func() { time.Sleep(20 * time.Millisecond); close(q.quit) }() }
func TestRegressionPartialFactoryWaitsForRollback(t *testing.T) {
	initLock.Lock()
	saved := initMap
	initMap = map[string]InitP{}
	initLock.Unlock()
	defer func() { initLock.Lock(); initMap = saved; initLock.Unlock() }()
	var count int
	var quit chan struct{}
	factory := func(q chan struct{}, _ chan<- []byte) common.MQ {
		count++
		if count == 2 {
			panic("second factory failed")
		}
		quit = q
		return &asyncRollbackMQ{quit: q}
	}
	AddMQ("first", factory)
	AddMQ("second", factory)
	if m, err := New(Options{}); err == nil || m != nil {
		t.Fatalf("partial state published: %v %v", m, err)
	}
	select {
	case <-quit:
	default:
		t.Fatal("rollback returned before resource completion")
	}
}
