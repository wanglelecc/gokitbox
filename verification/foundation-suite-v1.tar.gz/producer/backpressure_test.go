package producer

import (
	"context"
	"errors"
	"github.com/wanglelecc/gokitbox/producer/common"
	"github.com/wanglelecc/gokitbox/producer/meta"
	"testing"
	"time"
)

func newBlockedProducer() (*ProxyManager, *blockedMq) {
	q := &blockedMq{input: make(chan []byte), release: make(chan struct{}), quit: make(chan struct{})}
	return &ProxyManager{input: make(chan []byte), mqMap: map[string]common.MQ{meta.Kafka: q}, quits: []chan struct{}{q.quit}, exit: make(chan string, 1), done: make(chan struct{}), stopping: make(chan struct{})}, q
}
func TestKafkaQueueWaitHonorsContext(t *testing.T) {
	m, _ := newBlockedProducer()
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := m.KafkaContext(ctx, "topic", []byte("payload")); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
}
func TestKafkaQueueWaitReleasedByShutdown(t *testing.T) {
	m, q := newBlockedProducer()
	go m.Run()
	sending := make(chan error, 1)
	go func() { sending <- m.KafkaContext(context.Background(), "topic", []byte("payload")) }()
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := m.CloseContext(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	select {
	case err := <-sending:
		if !errors.Is(err, ErrProducerClosed) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("enqueue remained blocked")
	}
	close(q.release)
	if err := m.CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := m.KafkaContext(context.Background(), "topic", nil); !errors.Is(err, ErrProducerClosed) {
		t.Fatal(err)
	}
}
func TestKafkaQueueAcceptanceKeepsEnvelope(t *testing.T) {
	m, q := newBlockedProducer()
	q.input = make(chan []byte, 1)
	if err := m.KafkaContext(context.Background(), "topic", []byte("hello"), "key"); err != nil {
		t.Fatal(err)
	}
	select {
	case msg := <-q.input:
		if len(msg) == 0 {
			t.Fatal("empty")
		}
	default:
		t.Fatal("not accepted")
	}
}
