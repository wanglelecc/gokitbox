package failmode

import (
	"errors"
	"testing"
)

func TestRegressionRetryFullReturnsError(t *testing.T) {
	q := make(chan []byte, 1)
	r := &Retry{}
	if err := r.TryDo(q, []byte("first")); err != nil {
		t.Fatal(err)
	}
	if err := r.TryDo(q, []byte("second")); !errors.Is(err, ErrRetryFull) {
		t.Fatal(err)
	}
	if string(<-q) != "first" {
		t.Fatal("overwritten")
	}
}
