package kafka

import (
	"bytes"
	"context"
	"errors"
	"sync"
	"testing"
	"time"

	native "github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"github.com/wanglelecc/gokitbox/producer/common"
)

func eventually(t *testing.T, budget time.Duration, f func() bool) {
	t.Helper()
	end := time.Now().Add(budget)
	for !f() {
		if time.Now().After(end) {
			t.Fatal("condition timed out")
		}
		time.Sleep(5 * time.Millisecond)
	}
}
func testOptions() Options {
	o := DefaultOptions()
	o.Brokers = []string{"127.0.0.1:1"}
	o.Timeout = 600 * time.Millisecond
	o.BufferLimit = 4
	o.FailMode = "retry"
	o.MaxRetries = 2
	o.RetryBackoff = 20 * time.Millisecond
	o.RetryBudget = 6 * time.Second
	return o
}
func clusterProducer(t *testing.T, down bool) (*native.MockCluster, *CKafka) {
	t.Helper()
	c, err := native.NewMockCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(c.Close)
	if err = c.CreateTopic("regression", 1, 1); err != nil {
		t.Fatal(err)
	}
	if down {
		if err = c.SetBrokerDown(1); err != nil {
			t.Fatal(err)
		}
	}
	o := testOptions()
	o.Brokers = []string{c.BootstrapServers()}
	k, err := New(o)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		ctx, cancel := context.WithTimeout(context.Background(), 2*time.Second)
		defer cancel()
		k.CloseContext(ctx)
		k.Wait(context.Background())
	})
	return c, k
}
func TestRegressionNativeRetryAfterFinalFailure(t *testing.T) {
	c, k := clusterProducer(t, true)
	if err := k.Submit(context.Background(), common.Message{Topic: "regression", Key: []byte("space key"), Value: []byte("payload")}); err != nil {
		t.Fatal(err)
	}
	eventually(t, 4*time.Second, func() bool { return k.Snapshot().Retried > 0 })
	if err := c.SetBrokerUp(1); err != nil {
		t.Fatal(err)
	}
	eventually(t, 8*time.Second, func() bool { return k.Snapshot().Pending == 0 })
	s := k.Snapshot()
	if s.Delivered != 1 || s.Failed != 0 || s.Retried < 1 {
		t.Fatalf("%+v", s)
	}
}
func TestRegressionNativeBoundedFailureAndCloseError(t *testing.T) {
	_, k := clusterProducer(t, true)
	if err := k.Submit(context.Background(), common.Message{Topic: "regression", Value: []byte("payload")}); err != nil {
		t.Fatal(err)
	}
	eventually(t, 8*time.Second, func() bool { return k.Snapshot().Failed == 1 })
	s := k.Snapshot()
	if s.Retried != 2 || s.Pending != 0 {
		t.Fatalf("%+v", s)
	}
	if err := k.CloseContext(context.Background()); err == nil {
		t.Fatal("terminal failure hidden")
	}
	k.Close()
	k.Close()
}
func TestRegressionNativeDrainAndPayloadOwnership(t *testing.T) {
	c, k := clusterProducer(t, false)
	key := []byte("key with spaces\x00")
	body := []byte("  payload\x00 with spaces\n")
	want := append([]byte(nil), body...)
	for i := 0; i < 20; i++ {
		if err := k.Submit(context.Background(), common.Message{Topic: "regression", Key: key, Value: body}); err != nil {
			t.Fatal(err)
		}
	}
	body[0] = 'X'
	key[0] = 'X'
	ctx, cancel := context.WithTimeout(context.Background(), 8*time.Second)
	defer cancel()
	if err := k.CloseContext(ctx); err != nil {
		t.Fatal(err)
	}
	s := k.Snapshot()
	if s.Accepted != 20 || s.Delivered != 20 || s.Pending != 0 || s.Failed != 0 {
		t.Fatalf("%+v", s)
	}
	if err := k.Submit(ctx, common.Message{Topic: "regression"}); !errors.Is(err, ErrClosed) {
		t.Fatal(err)
	}
	consumer, err := native.NewConsumer(&native.ConfigMap{"bootstrap.servers": c.BootstrapServers(), "group.id": "producer-regression", "auto.offset.reset": "earliest", "enable.auto.commit": false})
	if err != nil {
		t.Fatal(err)
	}
	defer consumer.Close()
	if err = consumer.Assign([]native.TopicPartition{{Topic: ptr("regression"), Partition: 0, Offset: native.OffsetBeginning}}); err != nil {
		t.Fatal(err)
	}
	for i := 0; i < 20; i++ {
		m, err := consumer.ReadMessage(5 * time.Second)
		if err != nil {
			t.Fatal(err)
		}
		if !bytes.Equal(m.Value, want) || string(m.Key) != "key with spaces\x00" {
			t.Fatalf("corrupt message: %q %q", m.Key, m.Value)
		}
	}
}
func ptr(s string) *string { return &s }
func TestRegressionShortTimeoutSDKAndInputValidation(t *testing.T) {
	o := testOptions()
	o.Timeout = time.Millisecond
	k, err := New(o)
	if err != nil {
		t.Fatal(err)
	}
	defer k.Close()
	if err = k.Submit(context.Background(), common.Message{Topic: "has spaces"}); err == nil {
		t.Fatal("invalid topic")
	}
	if err = k.Submit(context.Background(), common.Message{Topic: "valid", Value: make([]byte, 1000001)}); err == nil {
		t.Fatal("oversize")
	}
	k.Input() <- []byte("malformed")
	eventually(t, time.Second, func() bool { return k.Snapshot().Failed == 1 })
	if err = k.CloseContext(context.Background()); err == nil {
		t.Fatal("malformed legacy input hidden")
	}
}

type fakeProducer struct {
	messages []*native.Message
	events   chan native.Event
	calls    int
	mode     string
	times    []time.Time
	closed   bool
	mu       sync.Mutex
}

func (f *fakeProducer) Events() chan native.Event { return f.events }
func (f *fakeProducer) Produce(m *native.Message, _ chan native.Event) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.calls++
	f.messages = append(f.messages, m)
	f.times = append(f.times, time.Now())
	switch f.mode {
	case "queue":
		if f.calls <= 2 {
			return native.NewError(native.ErrQueueFull, "full", false)
		}
	case "permanent":
		return native.NewError(native.ErrMsgSizeTooLarge, "size", false)
	case "hang":
		return nil
	case "panic":
		panic("injected native failure")
	}
	f.events <- m
	return nil
}
func (f *fakeProducer) Flush(int) int {
	if f.mode == "remaining" {
		return 1
	}
	return 0
}
func (f *fakeProducer) Close() { f.mu.Lock(); f.closed = true; f.mu.Unlock(); close(f.events) }
func fakeKafka(mode string) *CKafka {
	o := testOptions().normalized()
	if mode == "budget" {
		o.RetryBudget = 50 * time.Millisecond
		mode = "hang"
	}
	k := &CKafka{producer: &fakeProducer{events: make(chan native.Event, 100), mode: mode}, options: o, input: make(chan []byte, 4), queue: make(chan *job, 4), slots: make(chan struct{}, 5), exit: make(chan struct{}), done: make(chan struct{})}
	go k.run(nil)
	return k
}
func TestRegressionImmediateErrorsUseBoundedPolicy(t *testing.T) {
	for _, mode := range []string{"queue", "permanent"} {
		t.Run(mode, func(t *testing.T) {
			k := fakeKafka(mode)
			if err := k.Submit(context.Background(), common.Message{Topic: "regression", Value: []byte("body")}); err != nil {
				t.Fatal(err)
			}
			eventually(t, time.Second, func() bool { return k.Snapshot().Pending == 0 })
			s := k.Snapshot()
			err := k.CloseContext(context.Background())
			f := k.producer.(*fakeProducer)
			if mode == "queue" {
				if err != nil || s.Delivered != 1 || s.Retried != 2 || f.calls != 3 {
					t.Fatalf("%+v %v calls=%d", s, err, f.calls)
				}
				if f.times[1].Sub(f.times[0]) < 20*time.Millisecond || f.times[2].Sub(f.times[1]) < 40*time.Millisecond {
					t.Fatal("backoff bypassed")
				}
			} else {
				if err == nil || s.Failed != 1 || s.Retried != 0 || f.calls != 1 {
					t.Fatalf("%+v %v", s, err)
				}
			}
		})
	}
}
func TestRegressionDeadlineBackpressureAndCompletion(t *testing.T) {
	k := fakeKafka("hang")
	for i := 0; i < 5; i++ {
		if err := k.Submit(context.Background(), common.Message{Topic: "regression"}); err != nil {
			t.Fatal(err)
		}
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := k.Submit(ctx, common.Message{Topic: "regression"}); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	closing, stop := context.WithTimeout(context.Background(), 30*time.Millisecond)
	defer stop()
	if err := k.CloseContext(closing); err == nil {
		t.Fatal("deadline hidden")
	}
	if err := k.Wait(context.Background()); err == nil {
		t.Fatal("unknown outcomes hidden")
	}
	s := k.Snapshot()
	if s.Accepted != 5 || s.Failed != 5 || s.Dropped != 5 || s.Pending != 0 {
		t.Fatalf("%+v", s)
	}
	k.Close()
	k.Close()
}
func TestRegressionPanicAndFlushCleanup(t *testing.T) {
	for _, mode := range []string{"panic", "remaining"} {
		t.Run(mode, func(t *testing.T) {
			k := fakeKafka(mode)
			if err := k.Submit(context.Background(), common.Message{Topic: "regression"}); err != nil {
				t.Fatal(err)
			}
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			if err := k.CloseContext(ctx); err == nil {
				t.Fatal("native failure hidden")
			}
			f := k.producer.(*fakeProducer)
			f.mu.Lock()
			closed := f.closed
			f.mu.Unlock()
			if !closed || k.Snapshot().Pending != 0 {
				t.Fatal("cleanup incomplete")
			}
		})
	}
}
func TestRegressionConcurrentAdmissionAndClose(t *testing.T) {
	k := fakeKafka("")
	var wg sync.WaitGroup
	for i := 0; i < 20; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := 0; j < 100; j++ {
				err := k.Submit(context.Background(), common.Message{Topic: "regression"})
				if err != nil && !errors.Is(err, ErrClosed) {
					t.Error(err)
				}
				if err != nil {
					return
				}
			}
		}()
	}
	time.Sleep(5 * time.Millisecond)
	if err := k.CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	wg.Wait()
	s := k.Snapshot()
	if s.Accepted != s.Delivered || s.Pending != 0 || s.Failed != 0 {
		t.Fatalf("%+v", s)
	}
}
func TestRegressionTotalBudgetIncludesInflight(t *testing.T) {
	k := fakeKafka("budget")
	if err := k.Submit(context.Background(), common.Message{Topic: "regression"}); err != nil {
		t.Fatal(err)
	}
	eventually(t, time.Second, func() bool { return k.Snapshot().Pending == 0 })
	s := k.Snapshot()
	if s.Failed != 1 || s.Dropped != 1 {
		t.Fatalf("%+v", s)
	}
	if err := k.CloseContext(context.Background()); err == nil {
		t.Fatal("unknown delivery hidden")
	}
}
func TestRegressionDiscardAsyncNoRetry(t *testing.T) {
	c, err := native.NewMockCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	if err = c.SetBrokerDown(1); err != nil {
		t.Fatal(err)
	}
	o := testOptions()
	o.Brokers = []string{c.BootstrapServers()}
	o.FailMode = "discard"
	k, err := New(o)
	if err != nil {
		t.Fatal(err)
	}
	defer k.Close()
	if err = k.Submit(context.Background(), common.Message{Topic: "regression"}); err != nil {
		t.Fatal(err)
	}
	eventually(t, 4*time.Second, func() bool { return k.Snapshot().Failed == 1 })
	s := k.Snapshot()
	if s.Retried != 0 || s.Pending != 0 {
		t.Fatalf("%+v", s)
	}
	if err = k.CloseContext(context.Background()); err == nil {
		t.Fatal("terminal failure hidden")
	}
}

func TestRegressionTypedNilAndEmptyKeyOwnership(t *testing.T) {
	k := fakeKafka("")
	if err := k.Submit(context.Background(), common.Message{Topic: "regression", Key: []byte{}, Value: []byte{}}); err != nil {
		t.Fatal(err)
	}
	if err := k.CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	f := k.producer.(*fakeProducer)
	if len(f.messages) != 1 || f.messages[0].Key == nil || f.messages[0].Value == nil {
		t.Fatal("empty key/value turned into null")
	}
}
func TestRegressionFatalEventCleansOwnedWork(t *testing.T) {
	k := fakeKafka("hang")
	if err := k.Submit(context.Background(), common.Message{Topic: "regression"}); err != nil {
		t.Fatal(err)
	}
	k.producer.(*fakeProducer).events <- native.NewError(native.ErrAllBrokersDown, "injected fatal", true)
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := k.Wait(ctx); err == nil || errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("fatal cleanup: %v", err)
	}
	s := k.Snapshot()
	if s.Failed != 1 || s.Dropped != 1 || s.Pending != 0 {
		t.Fatalf("%+v", s)
	}
}
func TestRegressionMalformedInputDoesNotKillRunner(t *testing.T) {
	k := fakeKafka("")
	k.Input() <- []byte("malformed")
	if err := k.Submit(context.Background(), common.Message{Topic: "regression", Value: []byte("body")}); err != nil {
		t.Fatal(err)
	}
	eventually(t, time.Second, func() bool { s := k.Snapshot(); return s.Failed == 1 && s.Delivered == 1 })
	if err := k.CloseContext(context.Background()); err == nil {
		t.Fatal("malformed input failure hidden")
	}
	if s := k.Snapshot(); s.Pending != 0 || s.Accepted != 2 {
		t.Fatalf("%+v", s)
	}
}
