package kafka

import (
	native "github.com/confluentinc/confluent-kafka-go/v2/kafka"

	"testing"
	"time"
)

func TestReviewAsyncFailureCannotRecoverTopicPartitionMetadata(t *testing.T) {
	cluster, err := native.NewMockCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	defer cluster.Close()
	if err = cluster.SetBrokerDown(1); err != nil {
		t.Fatal(err)
	}
	p, err := native.NewProducer(&native.ConfigMap{"bootstrap.servers": cluster.BootstrapServers(), "message.timeout.ms": 250, "linger.ms": 0})
	if err != nil {
		t.Fatal(err)
	}
	defer p.Close()
	topic, metadata := "review-topic", "timestamp kafka topic key payload"
	delivery := make(chan native.Event, 1)
	if err = p.Produce(&native.Message{TopicPartition: native.TopicPartition{Topic: &topic, Partition: native.PartitionAny, Metadata: &metadata}, Opaque: "expected-context", Value: []byte("body")}, delivery); err != nil {
		t.Fatal(err)
	}
	select {
	case event := <-delivery:
		report := event.(*native.Message)
		if report.TopicPartition.Error == nil {
			t.Fatal("failure was not injected")
		}
		if report.TopicPartition.Metadata != nil {
			t.Fatal("baseline changed: metadata is retained")
		}
		if report.Opaque != "expected-context" {
			t.Fatal("opaque context not retained")
		}
		t.Log("CONFIRMED: failure report loses TopicPartition.Metadata; Opaque survives")
	case <-time.After(3 * time.Second):
		t.Fatal("no delivery report")
	}
}
