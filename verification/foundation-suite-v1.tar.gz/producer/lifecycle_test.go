package producer

import (
	"context"
	"errors"
	"github.com/wanglelecc/gokitbox/producer/common"
	"sync"
	"testing"
	"time"
)

type blockedMq struct {
	input   chan []byte
	release chan struct{}
	quit    chan struct{}
	once    sync.Once
}

func (m *blockedMq) Input() chan<- []byte { return m.input }
func (m *blockedMq) Close()               { m.once.Do(func() { <-m.release; close(m.quit) }) }
func (m *blockedMq) SetFailMode()         {}
func TestCloseContextInterruptsBackpressureAndReportsIncomplete(t *testing.T) {
	quit := make(chan struct{})
	mq := &blockedMq{input: make(chan []byte), release: make(chan struct{}), quit: quit}
	m := &ProxyManager{input: make(chan []byte), mqMap: map[string]common.MQ{"fake": mq}, quits: []chan struct{}{quit}, exit: make(chan string, 1), done: make(chan struct{})}
	go m.Run()
	// Close must wait for the blocked plugin to actually finish.
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := m.CloseContext(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("incomplete drain hidden: %v", err)
	}
	close(mq.release)
	ctx2, stop := context.WithTimeout(context.Background(), time.Second)
	defer stop()
	if err := m.CloseContext(ctx2); err != nil {
		t.Fatal(err)
	}
	if err := m.CloseContext(ctx2); err != nil {
		t.Fatal(err)
	}
}
