package producer

import (
	"testing"

	"github.com/wanglelecc/gokitbox/producer/kafka"
)

func TestOptionsAreValidatedAndCopied(t *testing.T) {
	optionsMu.Lock()
	saved, savedStarted := configuredOptions, started
	optionsMu.Unlock()
	t.Cleanup(func() { optionsMu.Lock(); configuredOptions, started = saved, savedStarted; optionsMu.Unlock() })

	o := Options{KafkaEnabled: true, Kafka: kafka.DefaultOptions(), BufferLimit: 0}
	o.Kafka.Brokers = []string{"localhost:9092"}
	if err := Configure(o); err != nil {
		t.Fatal(err)
	}
	o.Kafka.Brokers[0] = "changed"
	if currentOptions().Kafka.Brokers[0] != "localhost:9092" {
		t.Fatal("broker list was not copied")
	}
	if err := Configure(o); err == nil {
		t.Fatal("reconfiguration accepted")
	}
}
