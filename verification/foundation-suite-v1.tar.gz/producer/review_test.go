package producer

import (
	"context"
	"github.com/wanglelecc/gokitbox/producer/common"
	"github.com/wanglelecc/gokitbox/producer/meta"
	"sync/atomic"
	"testing"
	"time"
)

type reviewMQ struct {
	input  chan []byte
	quit   chan struct{}
	looked chan struct{}
	calls  atomic.Int32
}

func (q *reviewMQ) Input() chan<- []byte {
	if q.looked != nil && q.calls.Add(1) == 1 {
		close(q.looked)
	}
	return q.input
}
func (q *reviewMQ) Close()       { close(q.quit) }
func (q *reviewMQ) SetFailMode() {}
func TestRegressionCloseReportsOwnedFallbackUnknown(t *testing.T) {
	q := &reviewMQ{input: make(chan []byte), quit: make(chan struct{}), looked: make(chan struct{})}
	m := &ProxyManager{input: make(chan []byte, 1), mqMap: map[string]common.MQ{meta.Kafka: q}, quits: []chan struct{}{q.quit}, exit: make(chan string, 1), done: make(chan struct{}), stopping: make(chan struct{})}
	m.input <- []byte("100 kafka topic key payload")
	go m.Run()
	<-q.looked
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := m.CloseContext(ctx); err == nil {
		t.Fatal("lost fallback outcome hidden")
	}
	if len(m.input) != 0 {
		t.Fatal("fixture not forwarded")
	}
}
func TestRegressionExplicitOptionsDisableKafka(t *testing.T) {
	initLock.Lock()
	saved := initMap
	initMap = make(map[string]InitP)
	initLock.Unlock()
	defer func() { initLock.Lock(); initMap = saved; initLock.Unlock() }()
	called := false
	AddMQ(meta.Kafka, func(quit chan struct{}, _ chan<- []byte) common.MQ {
		called = true
		return &reviewMQ{input: make(chan []byte, 1), quit: quit}
	})
	m := NewProxyManagerWithOptions(Options{KafkaEnabled: false, BufferLimit: 1})
	defer m.Close()
	if called || m.mqMap[meta.Kafka] != nil {
		t.Fatal("baseline changed: explicit enable flag is honored")
	}
}

func TestRegressionSpaceInKeyPreserved(t *testing.T) {
	q := &reviewMQ{input: make(chan []byte, 1)}
	m := &ProxyManager{mqMap: map[string]common.MQ{meta.Kafka: q}, stopping: make(chan struct{})}
	if err := m.KafkaContext(context.Background(), "topic", []byte("payload"), "key with space"); err != nil {
		t.Fatal(err)
	}
	m2, err := common.Decode(<-q.input)
	if err != nil || string(m2.Key) != "key with space" || string(m2.Value) != "payload" {
		t.Fatalf("corrupted: %+v %v", m2, err)
	}
}
