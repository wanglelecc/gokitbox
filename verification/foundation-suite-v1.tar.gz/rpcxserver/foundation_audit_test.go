package rpcxserver

import (
	"context"
	"crypto/hmac"
	"crypto/md5"
	"crypto/sha256"
	"encoding/hex"
	"github.com/smallnest/rpcx/protocol"
	"strconv"
	"testing"
	"time"
)

func auditServer() *Server {
	return &Server{validAuth: map[string]string{"client": "secret"}, accessFn: func(app string) (string, bool) { return "secret", app == "client" }, usedNonces: map[string]time.Time{}}
}
func auditRequest(nonce bool) *protocol.Message {
	ts := strconv.FormatInt(time.Now().Unix(), 10)
	r := protocol.NewMessage()
	r.ServicePath = "A"
	r.ServiceMethod = "Read"
	r.Payload = []byte("one")
	r.Metadata = map[string]string{"X-Auth-AppId": "client", "X-Auth-Timestamp": ts}
	if nonce {
		r.Metadata["X-Auth-Nonce"] = "nonce"
		mac := hmac.New(sha256.New, []byte("secret"))
		mac.Write([]byte("client|" + ts + "|nonce"))
		r.Metadata["X-Auth-Sign"] = hex.EncodeToString(mac.Sum(nil))
	} else {
		r.Metadata["X-Auth-Sign"] = legacySign(ts)
	}
	return r
}

func legacySign(ts string) string {
	x := md5.Sum([]byte("client&" + ts + "secret"))
	return hex.EncodeToString(x[:])
}
func TestFoundationLegacyReplay(t *testing.T) {
	s := auditServer()
	r := auditRequest(false)
	for i := 0; i < 3; i++ {
		if err := s.auth(context.Background(), r, ""); err == nil {
			t.Fatal(err)
		}
	}
	t.Log("same signed request accepted three times without nonce")
}
func TestFoundationCrossInstanceAndPayloadReplay(t *testing.T) {
	r := auditRequest(true)
	s1, s2 := auditServer(), auditServer()
	if err := s1.auth(context.Background(), r, ""); err == nil {
		t.Fatal(err)
	}
	r.ServicePath = "Other"
	r.ServiceMethod = "Write"
	r.Payload = []byte("modified")
	if err := s2.auth(context.Background(), r, ""); err == nil {
		t.Fatal(err)
	}
	t.Log("same signature accepted at second instance after method and payload change")
}
