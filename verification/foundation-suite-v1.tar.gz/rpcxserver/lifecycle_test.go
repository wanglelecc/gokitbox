package rpcxserver

import (
	"context"
	"errors"
	"net"
	"testing"
	"time"
)

func TestExternalLifecycle(t *testing.T) {
	for _, network := range []string{"tcp", "http"} {
		t.Run(network, func(t *testing.T) {
			o := DefaultOptions()
			o.Addr = "127.0.0.1"
			o.Port = "0"
			o.Network = network
			s := NewServerWithOptions(o)
			stops := 0
			s.registryStops = append(s.registryStops, func() error { stops++; return nil })
			s.AddBeforeServerStartFunc(s.DisableHTTPGateway())
			ctx, cancel := context.WithTimeout(context.Background(), time.Second)
			defer cancel()
			if err := s.Start(ctx); err != nil {
				t.Fatal(err)
			}
			cancel()
			if s.listener == nil {
				t.Fatal("ready without listener")
			}
			stopCtx, stop := context.WithTimeout(context.Background(), time.Second)
			defer stop()
			if err := s.Stop(stopCtx); err != nil {
				t.Fatal(err)
			}
			if err := s.Wait(); err != nil {
				t.Fatal(err)
			}
			if err := s.Stop(stopCtx); err != nil {
				t.Fatal(err)
			}
			if stops != 1 {
				t.Fatalf("registry stopped %d times", stops)
			}
		})
	}
}
func TestBindFailure(t *testing.T) {
	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer ln.Close()
	host, port, _ := net.SplitHostPort(ln.Addr().String())
	o := DefaultOptions()
	o.Addr = host
	o.Port = port
	s := NewServerWithOptions(o)
	if err := s.Start(context.Background()); err == nil {
		t.Fatal("bind error hidden")
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := s.Stop(ctx); err != nil {
		t.Fatal(err)
	}
}

func TestStopContextBoundsRegistryCleanup(t *testing.T) {
	o := DefaultOptions()
	o.Addr = "127.0.0.1"
	o.Port = "0"
	s := NewServerWithOptions(o)
	s.AddBeforeServerStartFunc(s.DisableHTTPGateway())
	release := make(chan struct{})
	s.registryStops = append(s.registryStops, func() error { <-release; return nil })
	if err := s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	err := s.Stop(ctx)
	close(release)
	if !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("registry cleanup ignored deadline: %v", err)
	}
	ctx2, cancel2 := context.WithTimeout(context.Background(), time.Second)
	defer cancel2()
	if err := s.Stop(ctx2); err != nil {
		t.Fatal(err)
	}
}
