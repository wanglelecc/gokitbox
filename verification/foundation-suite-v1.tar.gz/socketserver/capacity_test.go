package socketserver

import (
	"bufio"
	"context"
	"errors"
	"io"
	"net"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func waitFor(t *testing.T, fn func() bool) {
	t.Helper()
	deadline := time.Now().Add(5 * time.Second)
	for !fn() {
		if time.Now().After(deadline) {
			t.Fatal("condition did not converge")
		}
		time.Sleep(time.Millisecond)
	}
}
func TestMaintenanceCoversEveryDueSessionUnderBacklog(t *testing.T) {
	var seen sync.Map
	o := testOptions()
	o.MaintenanceInterval = 100 * time.Millisecond
	o.MaxPendingConnections = 0
	connected := make(chan struct{}, 1)
	s := startServer(t, o, Hooks{OnConnect: func(context.Context, *Session) error { connected <- struct{}{}; return nil }, OnMaintain: func(ctx context.Context, session *Session) error {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-time.After(2 * time.Millisecond):
		}
		seen.Store(session.ID(), true)
		return nil
	}})
	const count = 1000
	for i := 0; i < count; i++ {
		a, b := net.Pipe()
		t.Cleanup(func() { b.Close() })
		if err := s.admit(&tcpConn{Conn: a, reader: bufio.NewReader(a), codec: &rawCodec{size: 1024}}); err != nil {
			t.Fatal(err)
		}
		<-connected
	}
	waitFor(t, func() bool {
		n := 0
		seen.Range(func(_, _ any) bool { n++; return true })
		return n == count && s.Stats().MaintenanceCalls >= count
	})
	if got := s.Stats(); got.MaintenanceCalls < count || got.MaintenanceMaxDelay == 0 {
		t.Fatal(got)
	}
}
func TestReadBudgetIncludesProcessingAndReturnsAfterClose(t *testing.T) {
	o := testOptions()
	o.MaxReadBytes = 6
	o.TCPFraming = "line"
	entered := make(chan struct{}, 1)
	release := make(chan struct{})
	s := startServer(t, o, Hooks{OnMessage: func(ctx context.Context, _ *Session, _ Message) error {
		entered <- struct{}{}
		select {
		case <-release:
			return nil
		case <-ctx.Done():
			return ctx.Err()
		}
	}})
	first, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer first.Close()
	first.Write([]byte("aaaa\n"))
	<-entered
	if got := s.Stats().ReadBytes; got != 4 {
		t.Fatal(got)
	}
	second, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer second.Close()
	second.Write([]byte("bbbb\n"))
	second.SetReadDeadline(time.Now().Add(time.Second))
	_, err = second.Read(make([]byte, 1))
	if err == nil {
		t.Fatal("budget did not reject")
	}
	if timeout, ok := err.(net.Error); ok && timeout.Timeout() {
		t.Fatal("second session was not closed")
	}
	close(release)
	first.Close()
	waitFor(t, func() bool { return s.Stats().ReadBytes == 0 })
}
func TestWriteBudgetLimitsConcurrentRetainedPayloads(t *testing.T) {
	o := testOptions()
	o.MaxWriteBytes = 6
	o.WriteTimeout = time.Second
	connected := make(chan *Session, 1)
	s := startServer(t, o, Hooks{OnConnect: func(_ context.Context, session *Session) error { connected <- session; return nil }})
	a, b := net.Pipe()
	defer b.Close()
	if err := s.admit(&tcpConn{Conn: a, reader: bufio.NewReader(a), codec: &rawCodec{size: 1024}}); err != nil {
		t.Fatal(err)
	}
	session := <-connected
	done := make(chan error, 1)
	go func() { done <- session.Send(context.Background(), Message{Type: BinaryMessage, Data: []byte("aaaa")}) }()
	waitFor(t, func() bool { return s.Stats().WriteBytes == 4 })
	if err := session.Send(context.Background(), Message{Type: BinaryMessage, Data: []byte("bbbb")}); !errors.Is(err, ErrQueueFull) {
		t.Fatal(err)
	}
	b.Close()
	<-done
	waitFor(t, func() bool { return s.Stats().WriteBytes == 0 })
}
func TestPendingAdmissionLimitCountsOnConnect(t *testing.T) {
	o := testOptions()
	o.MaxPendingConnections = 1
	entered := make(chan struct{}, 1)
	s := startServer(t, o, Hooks{OnConnect: func(ctx context.Context, _ *Session) error { entered <- struct{}{}; <-ctx.Done(); return ctx.Err() }})
	a, b := net.Pipe()
	defer b.Close()
	if err := s.admit(&tcpConn{Conn: a, reader: bufio.NewReader(a), codec: &rawCodec{size: 1024}}); err != nil {
		t.Fatal(err)
	}
	<-entered
	c, d := net.Pipe()
	defer c.Close()
	defer d.Close()
	if err := s.admit(&tcpConn{Conn: c, reader: bufio.NewReader(c), codec: &rawCodec{size: 1024}}); !errors.Is(err, ErrTooManyConnections) {
		t.Fatal(err)
	}
	if got := s.Stats().PendingConnections; got != 1 {
		t.Fatal(got)
	}
}

type scratchCodec struct {
	buffer [1]byte
	reads  atomic.Int64
}

func (c *scratchCodec) ReadFrame(reader *bufio.Reader) ([]byte, error) {
	if _, err := io.ReadFull(reader, c.buffer[:]); err != nil {
		return nil, err
	}
	c.reads.Add(1)
	return c.buffer[:], nil
}
func (c *scratchCodec) WriteFrame(w io.Writer, data []byte) error { return writeAll(w, data) }
func TestCustomCodecScratchBufferRemainsIsolated(t *testing.T) {
	codec := &scratchCodec{}
	first := make(chan struct{}, 1)
	release := make(chan struct{})
	got := make(chan string, 2)
	var calls atomic.Int64
	s := startServer(t, testOptions(), Hooks{OnMessage: func(ctx context.Context, _ *Session, m Message) error {
		if calls.Add(1) == 1 {
			first <- struct{}{}
			select {
			case <-release:
			case <-ctx.Done():
				return ctx.Err()
			}
		}
		got <- string(m.Data)
		return nil
	}})
	a, b := net.Pipe()
	defer b.Close()
	if err := s.admit(&tcpConn{Conn: a, reader: bufio.NewReader(a), codec: codec}); err != nil {
		t.Fatal(err)
	}
	b.Write([]byte("a"))
	<-first
	b.Write([]byte("b"))
	waitFor(t, func() bool { return codec.reads.Load() == 2 })
	close(release)
	for _, want := range []string{"a", "b"} {
		select {
		case value := <-got:
			if value != want {
				t.Fatalf("got %q want %q", value, want)
			}
		case <-time.After(time.Second):
			t.Fatal("message lost")
		}
	}
}
