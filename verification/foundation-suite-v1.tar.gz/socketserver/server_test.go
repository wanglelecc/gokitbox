package socketserver

import (
	"bufio"
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"

	ws "github.com/gorilla/websocket"
)

func testOptions() Options {
	o := DefaultOptions()
	o.Addr = "127.0.0.1:0"
	o.IdleTimeout = 0
	o.LoginTimeout = 0
	o.CheckInterval = 10 * time.Millisecond
	o.ShutdownTimeout = time.Second
	return o
}
func startServer(t *testing.T, o Options, h Hooks) *Server {
	t.Helper()
	h.OnError = func(context.Context, ErrorEvent) {}
	s, err := NewServerWithOptions(o, WithHooks(h))
	if err != nil {
		t.Fatal(err)
	}
	if err = s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() {
		if err := s.Stop(context.Background()); err != nil {
			t.Error(err)
		}
		s.Wait()
	})
	return s
}
func TestRawTCPReadAheadAndHalfClose(t *testing.T) {
	var gotMu sync.Mutex
	var got []byte
	closed := make(chan struct{})
	o := testOptions()
	o.ReadBufferSize = 1024
	s := startServer(t, o, Hooks{OnMessage: func(ctx context.Context, session *Session, message Message) error {
		gotMu.Lock()
		got = append(got, message.Data...)
		gotMu.Unlock()
		return session.Send(ctx, message)
	}, OnDisconnect: func(context.Context, *Session, CloseReason) error { close(closed); return nil }})
	conn, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	payload := bytes.Repeat([]byte("tcp-data"), 3000)
	if _, err = conn.Write(payload); err != nil {
		t.Fatal(err)
	}
	conn.(*net.TCPConn).CloseWrite()
	conn.SetReadDeadline(time.Now().Add(2 * time.Second))
	received, err := io.ReadAll(conn)
	if err != nil || !bytes.Equal(received, payload) {
		t.Fatalf("read data lost: sent=%d received=%d error=%v", len(payload), len(received), err)
	}
	select {
	case <-closed:
	case <-time.After(time.Second):
		t.Fatal("disconnect did not complete")
	}
	gotMu.Lock()
	defer gotMu.Unlock()
	if !bytes.Equal(got, payload) {
		t.Fatalf("hook data lost: %d", len(got))
	}
	if s.Connections().Count() != 0 {
		t.Fatal("closed connection remained online")
	}
}
func TestWebSocketFramesOriginAndLimit(t *testing.T) {
	o := testOptions()
	o.Network = "websocket"
	o.AllowedOrigins = []string{"https://allowed.example"}
	o.MaxMessageBytes = 128
	s := startServer(t, o, Hooks{OnMessage: func(ctx context.Context, session *Session, message Message) error { return session.Send(ctx, message) }})
	url := "ws://" + s.Addr().String() + o.WebSocketPath
	header := http.Header{"Origin": []string{"https://denied.example"}}
	if c, resp, err := ws.DefaultDialer.Dial(url, header); err == nil {
		c.Close()
		t.Fatal("origin allowed")
	} else if resp != nil {
		resp.Body.Close()
	}
	header.Set("Origin", "https://allowed.example")
	c, _, err := ws.DefaultDialer.Dial(url, header)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	for _, kind := range []int{ws.TextMessage, ws.BinaryMessage} {
		data := []byte("ws-frame")
		if err = c.WriteMessage(kind, data); err != nil {
			t.Fatal(err)
		}
		c.SetReadDeadline(time.Now().Add(time.Second))
		gotKind, got, err := c.ReadMessage()
		if err != nil || gotKind != kind || !bytes.Equal(got, data) {
			t.Fatal(gotKind, string(got), err)
		}
	}
	if err = c.WriteMessage(ws.BinaryMessage, make([]byte, 129)); err != nil {
		t.Fatal(err)
	}
	if _, _, err = c.ReadMessage(); err == nil {
		t.Fatal("oversize frame accepted")
	}
}
func TestFraming(t *testing.T) {
	for _, mode := range []string{"line", "length-prefix"} {
		t.Run(mode, func(t *testing.T) {
			o := testOptions()
			o.TCPFraming = mode
			s := startServer(t, o, Hooks{OnMessage: func(ctx context.Context, session *Session, message Message) error { return session.Send(ctx, message) }})
			conn, err := net.Dial("tcp", s.Addr().String())
			if err != nil {
				t.Fatal(err)
			}
			defer conn.Close()
			conn.SetDeadline(time.Now().Add(time.Second))
			payload := []byte("frame")
			if mode == "line" {
				conn.Write(append(payload, '\n'))
				line, err := bufio.NewReader(conn).ReadBytes('\n')
				if err != nil || string(line) != "frame\n" {
					t.Fatal(string(line), err)
				}
			} else {
				var header [4]byte
				binary.BigEndian.PutUint32(header[:], uint32(len(payload)))
				conn.Write(header[:2])
				conn.Write(append(header[2:], payload...))
				var got [9]byte
				if _, err = io.ReadFull(conn, got[:]); err != nil || !bytes.Equal(got[4:], payload) {
					t.Fatal(got, err)
				}
			}
		})
	}
}
func TestQueueCancellationAndSingleDisconnect(t *testing.T) {
	entered := make(chan struct{})
	var once sync.Once
	var disconnects atomic.Int32
	o := testOptions()
	o.ReadBufferSize = 1
	o.ReadQueueSize = 1
	o.ReadQueueBytes = 0
	s := startServer(t, o, Hooks{OnMessage: func(ctx context.Context, _ *Session, _ Message) error {
		once.Do(func() { close(entered) })
		<-ctx.Done()
		return ctx.Err()
	}, OnDisconnect: func(context.Context, *Session, CloseReason) error { disconnects.Add(1); return nil }})
	conn, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer conn.Close()
	conn.Write([]byte("overflow"))
	select {
	case <-entered:
	case <-time.After(time.Second):
		t.Fatal("handler did not start")
	}
	if err = s.Stop(context.Background()); err != nil {
		t.Fatal(err)
	}
	if disconnects.Load() != 1 {
		t.Fatal("disconnect count", disconnects.Load())
	}
}
func TestAdmissionFailureAndCapacity(t *testing.T) {
	o := testOptions()
	o.Network = "websocket"
	var disconnects atomic.Int32
	s := startServer(t, o, Hooks{OnConnect: func(context.Context, *Session) error { return errors.New("reject") }, OnDisconnect: func(context.Context, *Session, CloseReason) error { disconnects.Add(1); return nil }})
	c, _, err := ws.DefaultDialer.Dial("ws://"+s.Addr().String()+o.WebSocketPath, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer c.Close()
	c.SetReadDeadline(time.Now().Add(time.Second))
	if _, _, err = c.ReadMessage(); err == nil {
		t.Fatal("rejected connection left open")
	}
	deadline := time.Now().Add(time.Second)
	for disconnects.Load() != 1 && time.Now().Before(deadline) {
		time.Sleep(time.Millisecond)
	}
	if disconnects.Load() != 1 || s.Connections().Count() != 0 {
		t.Fatal("admission not rolled back")
	}
}
func TestTwoIndependentServersAndState(t *testing.T) {
	makeNode := func() *Server {
		return startServer(t, testOptions(), Hooks{OnMessage: func(ctx context.Context, s *Session, m Message) error { return s.Send(ctx, m) }})
	}
	a, b := makeNode(), makeNode()
	if a.Addr().String() == b.Addr().String() || a.Connections() == b.Connections() {
		t.Fatal("shared runtime")
	}
	for _, s := range []*Server{a, b} {
		c, err := net.Dial("tcp", s.Addr().String())
		if err != nil {
			t.Fatal(err)
		}
		c.SetDeadline(time.Now().Add(time.Second))
		c.Write([]byte("node"))
		got := make([]byte, 4)
		if _, err = io.ReadFull(c, got); err != nil || string(got) != "node" {
			t.Fatal(got, err)
		}
		c.Close()
	}
}
func TestBindRollbackAndCanceledStop(t *testing.T) {
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	defer listener.Close()
	o := testOptions()
	o.Addr = listener.Addr().String()
	s, _ := NewServerWithOptions(o)
	if s.Start(context.Background()) == nil {
		t.Fatal("bind error hidden")
	}
	s.Stop(context.Background())
	s, _ = NewServerWithOptions(testOptions())
	if err = s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { s.Stop(context.Background()); s.Wait() })
	addr := s.Addr().String()
	ctx, cancel := context.WithCancel(context.Background())
	cancel()
	s.Stop(ctx)
	deadline := time.Now().Add(time.Second)
	for {
		l, err := net.Listen("tcp", addr)
		if err == nil {
			l.Close()
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("canceled stop leaked listener")
		}
		time.Sleep(time.Millisecond)
	}
}
func TestLineLimitAndPartialFrame(t *testing.T) {
	codec := &lineCodec{delimiter: '\n', limit: 3}
	if _, err := codec.ReadFrame(bufio.NewReader(strings.NewReader("four\n"))); !errors.Is(err, ErrMessageTooLarge) {
		t.Fatal(err)
	}
	if _, err := codec.ReadFrame(bufio.NewReader(strings.NewReader("end"))); !errors.Is(err, io.ErrUnexpectedEOF) {
		t.Fatal(err)
	}
}

func TestSlowWriteCancellationAndConcurrentState(t *testing.T) {
	connected := make(chan *Session, 1)
	o := testOptions()
	o.WriteTimeout = 40 * time.Millisecond
	s := startServer(t, o, Hooks{OnConnect: func(_ context.Context, session *Session) error { connected <- session; return nil }})
	receiver, peer := net.Pipe()
	defer peer.Close()
	if err := s.admit(&tcpConn{Conn: receiver, reader: bufio.NewReader(receiver), codec: &rawCodec{size: 1024}}); err != nil {
		t.Fatal(err)
	}
	session := <-connected
	var wg sync.WaitGroup
	for i := 0; i < 32; i++ {
		wg.Add(1)
		go func() { defer wg.Done(); session.MarkAuthenticated(); session.Authenticated(); session.Closed() }()
	}
	wg.Wait()
	before := time.Now()
	err := session.Send(context.Background(), Message{Type: BinaryMessage, Data: []byte("blocked")})
	if !errors.Is(err, context.DeadlineExceeded) || time.Since(before) > time.Second {
		t.Fatalf("write was not bounded: %v", err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err = session.Wait(ctx); err != nil {
		t.Fatal(err)
	}
	if s.Connections().Count() != 0 {
		t.Fatal("timed-out session remained online")
	}
}
func TestDuplicateAndCapacityDoNotReplaceOwner(t *testing.T) {
	connected := make(chan *Session, 1)
	o := testOptions()
	o.MaxConnections = 1
	s, err := NewServerWithOptions(o, WithIDGenerator(func() (string, error) { return "owner", nil }), WithHooks(Hooks{OnConnect: func(_ context.Context, s *Session) error { connected <- s; return nil }, OnError: func(context.Context, ErrorEvent) {}}))
	if err != nil {
		t.Fatal(err)
	}
	if err = s.Start(context.Background()); err != nil {
		t.Fatal(err)
	}
	defer s.Stop(context.Background())
	first, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer first.Close()
	session := <-connected
	second, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer second.Close()
	second.SetReadDeadline(time.Now().Add(time.Second))
	var b [1]byte
	if _, err = second.Read(b[:]); err == nil {
		t.Fatal("capacity not enforced")
	}
	if current, err := s.Connections().Get("owner"); err != nil || current != session {
		t.Fatal("owner replaced", err)
	}
}
func TestStartupPanicReturnsErrorWithoutBinding(t *testing.T) {
	o := testOptions()
	o.Network = "websocket"
	s, err := NewServerWithOptions(o, WithHTTPRoutes(func(*http.ServeMux) { panic("private") }))
	if err != nil {
		t.Fatal(err)
	}
	if err = s.Start(context.Background()); err == nil || strings.Contains(err.Error(), "private") {
		t.Fatal(err)
	}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err = s.Stop(ctx); err != nil {
		t.Fatal(err)
	}
}
func TestConcurrentStartStop(t *testing.T) {
	for i := 0; i < 30; i++ {
		s, _ := NewServerWithOptions(testOptions())
		done := make(chan struct{})
		go func() { s.Start(context.Background()); close(done) }()
		s.Stop(context.Background())
		<-done
	}
}

func BenchmarkTCPRoundTrip(b *testing.B) {
	o := testOptions()
	s, err := NewServerWithOptions(o, WithHooks(Hooks{OnMessage: func(ctx context.Context, s *Session, m Message) error { return s.Send(ctx, m) }, OnError: func(context.Context, ErrorEvent) {}}))
	if err != nil {
		b.Fatal(err)
	}
	if err = s.Start(context.Background()); err != nil {
		b.Fatal(err)
	}
	defer s.Stop(context.Background())
	conn, err := net.Dial("tcp", s.Addr().String())
	if err != nil {
		b.Fatal(err)
	}
	defer conn.Close()
	payload := bytes.Repeat([]byte("x"), 1024)
	received := make([]byte, len(payload))
	b.SetBytes(int64(len(payload)))
	b.ReportAllocs()
	b.ResetTimer()
	for i := 0; i < b.N; i++ {
		if _, err = conn.Write(payload); err != nil {
			b.Fatal(err)
		}
		if _, err = io.ReadFull(conn, received); err != nil {
			b.Fatal(err)
		}
	}
}
