package uNo

import (
	"strings"
	"sync"
	"testing"
)

func TestUniqueNumbers(t *testing.T) {
	var wg sync.WaitGroup
	var seen sync.Map
	for n := 0; n < 20; n++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for i := 0; i < 1000; i++ {
				v := GenOrderNo(1)
				if len(v) != 28 || !strings.HasPrefix(v, "YD") {
					t.Error("format", v)
				}
				if _, dup := seen.LoadOrStore(v, true); dup {
					t.Error("duplicate", v)
				}
			}
		}()
	}
	wg.Wait()
}
func TestNoTruncation(t *testing.T) {
	defer func() {
		if recover() == nil {
			t.Fatal("unsafe length accepted")
		}
	}()
	GenOrderNo(1, Option{Length: 18})
}
func TestCustomPrefixAndPadding(t *testing.T) {
	v := GenOrderNo(1, Option{Prefix: "T", Length: 45})
	if len(v) != 46 || !strings.HasPrefix(v, "TYD") {
		t.Fatal(v)
	}
}
