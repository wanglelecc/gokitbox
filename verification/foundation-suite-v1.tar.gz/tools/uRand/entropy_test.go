package uRand

import (
	"crypto/rand"
	"errors"
	"testing"
)

type failedEntropy struct{}

func (failedEntropy) Read([]byte) (int, error) { return 0, errors.New("entropy unavailable") }
func TestEntropyFailureDoesNotReturnPredictableToken(t *testing.T) {
	old := rand.Reader
	rand.Reader = failedEntropy{}
	defer func() { rand.Reader = old }()
	for _, fn := range []func(){func() { NewRandInt(10) }, func() { NewRandString(10) }} {
		panicked := false
		func() { defer func() { panicked = recover() != nil }(); fn() }()
		if !panicked {
			t.Fatal("entropy error produced a predictable result")
		}
	}
}
