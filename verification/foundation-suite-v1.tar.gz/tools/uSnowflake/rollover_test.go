package uSnowflake

import (
	"context"
	"errors"
	"sync/atomic"
	"testing"
	"time"
)

type cancelledWait struct {
	context.Context
	cancelled atomic.Bool
}

func (c *cancelledWait) Done() <-chan struct{} {
	c.cancelled.Store(true)
	done := make(chan struct{})
	close(done)
	return done
}
func (c *cancelledWait) Err() error {
	if c.cancelled.Load() {
		return context.Canceled
	}
	return nil
}
func TestCancelledRolloverDoesNotResetCommittedSequence(t *testing.T) {
	for i := 0; i < 100; i++ {
		now := time.Now().UnixMilli()
		g := &Generator{window: Window{Node: 0, Start: now, End: now + 1000}, until: time.Now().Add(time.Second), last: now, sequence: 4095}
		_, err := g.Next(&cancelledWait{Context: context.Background()})
		if !errors.Is(err, context.Canceled) {
			continue
		}
		if g.last != now || g.sequence != 4095 {
			t.Fatalf("cancelled rollover committed state: %d %d", g.last, g.sequence)
		}
		return
	}
	t.Fatal("failed to exercise rollover cancellation")
}
