package consumer

import (
	"context"
	"fmt"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"strings"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

// librdkafka's isolated mock cluster uses actual Kafka protocol listeners and
// real consumers/producers/groups. It is not a production broker durability test.
func TestKafkaNativeProtocolBrokerOutageAndRedelivery(t *testing.T) {
	cluster, err := kafka.NewMockCluster(1)
	if err != nil {
		t.Fatal(err)
	}
	defer cluster.Close()
	topic, failed, group := "source", "failed", fmt.Sprint("reliability-", time.Now().UnixNano())
	if err = cluster.CreateTopic(topic, 1, 1); err != nil {
		t.Fatal(err)
	}
	if err = cluster.CreateTopic(failed, 1, 1); err != nil {
		t.Fatal(err)
	}
	producer, err := kafka.NewProducer(&kafka.ConfigMap{"bootstrap.servers": cluster.BootstrapServers(), "acks": "all"})
	if err != nil {
		t.Fatal(err)
	}
	defer producer.Close()
	deliveries := make(chan kafka.Event, 2)
	for _, body := range []string{"bad", "good"} {
		if err = producer.Produce(&kafka.Message{TopicPartition: kafka.TopicPartition{Topic: &topic, Partition: 0}, Value: []byte(body)}, deliveries); err != nil {
			t.Fatal(err)
		}
	}
	for i := 0; i < 2; i++ {
		select {
		case event := <-deliveries:
			if m := event.(*kafka.Message); m.TopicPartition.Error != nil {
				t.Fatal(m.TopicPartition.Error)
			}
		case <-time.After(5 * time.Second):
			t.Fatal("setup produce timeout")
		}
	}
	entered, release := make(chan struct{}), make(chan struct{})
	var once sync.Once
	var badCount, goodCount atomic.Int32
	options := RuntimeOptions{HandlerTimeout: 5 * time.Second, RetryDelay: 10 * time.Millisecond, DeliveryTimeout: 250 * time.Millisecond, OperationTimeout: time.Second, SessionTimeout: 6 * time.Second}
	cfg := &KafkaConfig{Host: strings.Split(cluster.BootstrapServers(), ","), Topic: topic, FailTopic: failed, ConsumerGroup: group, ConsumerCount: 1}
	consumer, err := NewKafkaConsumerWithContext([]*KafkaConfig{cfg}, func(ctx context.Context, _ string, _ string, value []byte) (bool, error) {
		if string(value) == "bad" {
			n := badCount.Add(1)
			if n == 1 {
				once.Do(func() { close(entered) })
				select {
				case <-release:
				case <-ctx.Done():
					return false, ctx.Err()
				}
			}
			return false, nil
		}
		goodCount.Add(1)
		return true, nil
	}, options, nil)
	if err != nil {
		t.Fatal(err)
	}
	defer func() {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := consumer.CloseContext(ctx); err != nil {
			t.Error(err)
		}
	}()
	select {
	case <-entered:
	case <-time.After(15 * time.Second):
		t.Fatal("initial group delivery timed out")
	}
	if err = cluster.SetBrokerDown(1); err != nil {
		t.Fatal(err)
	}
	close(release)
	time.Sleep(1100 * time.Millisecond)
	if goodCount.Load() != 0 {
		t.Fatal("later offset processed while failed transfer was unresolved")
	}
	if err = cluster.SetBrokerUp(1); err != nil {
		t.Fatal(err)
	}
	deadline := time.Now().Add(20 * time.Second)
	for goodCount.Load() == 0 {
		if time.Now().After(deadline) {
			t.Fatalf("did not recover: bad=%d good=%d", badCount.Load(), goodCount.Load())
		}
		time.Sleep(20 * time.Millisecond)
	}
	if badCount.Load() < 2 {
		t.Fatal("unresolved source was not redelivered")
	}
	observer, err := kafka.NewConsumer(&kafka.ConfigMap{"bootstrap.servers": cluster.BootstrapServers(), "group.id": group, "enable.auto.commit": false})
	if err != nil {
		t.Fatal(err)
	}
	defer observer.Close()
	for {
		offsets, e := observer.Committed([]kafka.TopicPartition{{Topic: &topic, Partition: 0}}, 2000)
		if e == nil && len(offsets) == 1 && offsets[0].Offset >= 2 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatalf("successful source not committed: %v %v", offsets, e)
		}
		time.Sleep(20 * time.Millisecond)
	}
}
