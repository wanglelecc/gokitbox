package consumer

import (
	"context"
	"errors"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"strings"
	"sync"
	"testing"
	"time"
)

type fakeFailureProducer struct {
	messages        []*kafka.Message
	flushes, closed int
}

func (p *fakeFailureProducer) Produce(msg *kafka.Message, delivery chan kafka.Event) error {
	p.messages = append(p.messages, msg)
	delivery <- msg
	return nil
}
func (p *fakeFailureProducer) Flush(int) int { p.flushes++; return 0 }
func (p *fakeFailureProducer) Close()        { p.closed++ }
func TestFailureProducerRoutingAndReuse(t *testing.T) {
	a := &KafkaConfig{Host: []string{"a:9092", "b:9092"}, FailTopic: "failed", SASL: &SASL{}}
	same := &KafkaConfig{Host: []string{"b:9092", "a:9092"}, FailTopic: "other_failed", SASL: &SASL{}}
	b := &KafkaConfig{Host: []string{"analytics:9092"}, FailTopic: "failed", SASL: &SASL{}}
	authenticated := &KafkaConfig{Host: []string{"a:9092", "b:9092"}, FailTopic: "failed", SASL: &SASL{Enabled: true, User: "separate", Password: "test-secret"}}
	skipped := &KafkaConfig{Host: []string{"unused:9092"}}
	created := 0
	producers, err := createFailureProducers([]*KafkaConfig{a, same, b, authenticated, skipped}, func(*KafkaConfig) (kafkaFailureProducer, error) { created++; return &fakeFailureProducer{}, nil })
	if err != nil {
		t.Fatal(err)
	}
	if created != 3 {
		t.Fatalf("created %d failure producers", created)
	}
	k := &KafkaConsumer{producers: producers}
	for _, cfg := range []*KafkaConfig{a, same, b, authenticated} {
		if err := k.sendByHashPartition(cfg, cfg.FailTopic, []byte("body"), []byte("key")); err != nil {
			t.Fatal(err)
		}
	}
	first := producers[kafkaResourceKey(a)].(*fakeFailureProducer)
	second := producers[kafkaResourceKey(b)].(*fakeFailureProducer)
	if len(first.messages) != 2 || len(second.messages) != 1 || len(producers[kafkaResourceKey(authenticated)].(*fakeFailureProducer).messages) != 1 {
		t.Fatal("messages crossed resource boundaries")
	}
	if *first.messages[1].TopicPartition.Topic != "other_failed" || *second.messages[0].TopicPartition.Topic != "failed" {
		t.Fatal("failure topic lost")
	}
	if err := k.sendByHashPartition(skipped, "failed", nil, nil); err == nil {
		t.Fatal("unconfigured resource fell back to another producer")
	}
}
func TestFailureProducerInitializationRollback(t *testing.T) {
	previous := &fakeFailureProducer{}
	failure := errors.New("injected failure")
	count := 0
	resources, err := createFailureProducers([]*KafkaConfig{{Host: []string{"a"}, FailTopic: "failed"}, {Host: []string{"b"}, FailTopic: "failed"}}, func(*KafkaConfig) (kafkaFailureProducer, error) {
		count++
		if count == 2 {
			return nil, failure
		}
		return previous, nil
	})
	if !errors.Is(err, failure) || resources != nil || previous.closed != 1 {
		t.Fatalf("partial resources not closed: %v", err)
	}
}
func TestKafkaProducerUsesResourceCredentials(t *testing.T) {
	cfg := &KafkaConfig{Host: []string{"secure:9092"}, SASL: &SASL{Enabled: true, User: "test-user", Password: "test-password"}}
	options := kafkaProducerOptions(cfg)
	for key, want := range map[string]interface{}{"bootstrap.servers": "secure:9092", "security.protocol": "sasl_plaintext", "sasl.mechanism": "PLAIN", "sasl.username": "test-user", "sasl.password": "test-password"} {
		if (*options)[key] != want {
			t.Fatalf("producer option %s lost", key)
		}
	}
	plain := kafkaProducerOptions(&KafkaConfig{Host: []string{"plain:9092"}, SASL: &SASL{User: "unused", Password: "must-not-be-applied"}})
	if (*plain)["security.protocol"] != "plaintext" {
		t.Fatal("plaintext resource changed")
	}
	for key := range *plain {
		if strings.HasPrefix(key, "sasl.") {
			t.Fatal("credentials applied to disabled SASL")
		}
	}
}
func TestCloseAllKafkaFailureProducersOnce(t *testing.T) {
	a, b := &fakeFailureProducer{}, &fakeFailureProducer{}
	k := &KafkaConsumer{quit: make(chan struct{}), wg: &sync.WaitGroup{}, producers: map[kafkaConnection]kafkaFailureProducer{{brokers: "a"}: a, {brokers: "b"}: b}}
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := k.CloseContext(ctx); err != nil {
		t.Fatal(err)
	}
	if err := k.CloseContext(ctx); err != nil {
		t.Fatal(err)
	}
	if a.closed != 1 || b.closed != 1 || a.flushes != 1 || b.flushes != 1 {
		t.Fatal("failure producers leaked or closed repeatedly")
	}
}
