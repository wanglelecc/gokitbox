package consumer

import (
	"context"
	"errors"
	"sync"
	"testing"
	"time"
)

func TestDrainTimeoutIsNotSuccessAndRetryWaits(t *testing.T) {
	wg := &sync.WaitGroup{}
	wg.Add(1)
	child := &RabbitmqConsumer{quit: make(chan struct{}), wg: wg}
	manager := &ConsumeManager{rabbitmq: child}
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := manager.CloseContext(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("timeout hidden: %v", err)
	}
	ctx2, cancel2 := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel2()
	if err := manager.CloseContext(ctx2); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatalf("retry incorrectly returned success: %v", err)
	}
	wg.Done()
	ctx3, cancel3 := context.WithTimeout(context.Background(), time.Second)
	defer cancel3()
	if err := manager.CloseContext(ctx3); err != nil {
		t.Fatal(err)
	}
}
