package consumer

import (
	"bytes"
	"context"
	"encoding/binary"
	"errors"
	"fmt"
	amqp "github.com/rabbitmq/amqp091-go"
	"io"
	"net"
	"sync/atomic"
	"testing"
	"time"
)

// A minimal, isolated AMQP wire peer exercises the actual amqp091-go parser,
// publisher-confirm and mandatory-return ordering, not a mocked SDK method.
func wireShort(s string) []byte { return append([]byte{byte(len(s))}, []byte(s)...) }
func wireLong(s string) []byte {
	b := make([]byte, 4)
	binary.BigEndian.PutUint32(b, uint32(len(s)))
	return append(b, []byte(s)...)
}
func wireMethod(class, method uint16, args []byte) []byte {
	b := make([]byte, 4)
	binary.BigEndian.PutUint16(b, class)
	binary.BigEndian.PutUint16(b[2:], method)
	return append(b, args...)
}
func wireSend(c net.Conn, kind byte, ch uint16, p []byte) error {
	header := make([]byte, 7)
	header[0] = kind
	binary.BigEndian.PutUint16(header[1:], ch)
	binary.BigEndian.PutUint32(header[3:], uint32(len(p)))
	if _, e := c.Write(append(append(header, p...), 206)); e != nil {
		return e
	}
	return nil
}
func wireRead(c net.Conn) (byte, uint16, []byte, error) {
	h := make([]byte, 7)
	if _, e := io.ReadFull(c, h); e != nil {
		return 0, 0, nil, e
	}
	n := binary.BigEndian.Uint32(h[3:])
	if n > 16<<20 {
		return 0, 0, nil, errors.New("bad frame")
	}
	p := make([]byte, int(n)+1)
	if _, e := io.ReadFull(c, p); e != nil {
		return 0, 0, nil, e
	}
	if p[len(p)-1] != 206 {
		return 0, 0, nil, errors.New("bad frame end")
	}
	return h[0], binary.BigEndian.Uint16(h[1:]), p[:len(p)-1], nil
}
func wireHeader(body []byte, mode uint8) []byte {
	b := make([]byte, 14)
	binary.BigEndian.PutUint16(b, 60)
	binary.BigEndian.PutUint64(b[4:], uint64(len(body)))
	binary.BigEndian.PutUint16(b[12:], 0x9080)
	b = append(b, wireShort("application/json")...)
	b = append(b, mode)
	return append(b, wireShort("message-1")...)
}
func startWireRabbit(t *testing.T, mode string) (string, *atomic.Bool, <-chan error) {
	t.Helper()
	l, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	t.Cleanup(func() { l.Close() })
	acked := &atomic.Bool{}
	done := make(chan error, 1)
	go func() {
		c, e := l.Accept()
		if e != nil {
			done <- e
			return
		}
		defer c.Close()
		c.SetDeadline(time.Now().Add(5 * time.Second))
		fail := func(e error) bool {
			if e != nil {
				done <- e
				return true
			}
			return false
		}
		header := make([]byte, 8)
		if _, e = io.ReadFull(c, header); fail(e) {
			return
		}
		start := append([]byte{0, 9}, []byte{0, 0, 0, 0}...)
		start = append(start, wireLong("PLAIN")...)
		start = append(start, wireLong("en_US")...)
		if fail(wireSend(c, 1, 0, wireMethod(10, 10, start))) {
			return
		}
		if _, _, _, e = wireRead(c); fail(e) {
			return
		}
		tune := make([]byte, 8)
		binary.BigEndian.PutUint16(tune, 2047)
		binary.BigEndian.PutUint32(tune[2:], 131072)
		binary.BigEndian.PutUint16(tune[6:], 10)
		if fail(wireSend(c, 1, 0, wireMethod(10, 30, tune))) {
			return
		}
		if _, _, _, e = wireRead(c); fail(e) {
			return
		}
		if _, _, _, e = wireRead(c); fail(e) {
			return
		}
		if fail(wireSend(c, 1, 0, wireMethod(10, 41, wireShort("")))) {
			return
		}
		for {
			kind, ch, p, err := wireRead(c)
			if err != nil {
				if mode == "timeout" || mode == "return" || mode == "nack" {
					done <- nil
				} else {
					done <- err
				}
				return
			}
			if kind != 1 || len(p) < 4 {
				continue
			}
			class, method := binary.BigEndian.Uint16(p), binary.BigEndian.Uint16(p[2:])
			var reply []byte
			switch {
			case class == 20 && method == 10:
				reply = wireMethod(20, 11, wireLong(""))
			case class == 60 && method == 10:
				reply = wireMethod(60, 11, nil)
			case class == 85 && method == 10:
				reply = wireMethod(85, 11, nil)
			case class == 60 && method == 20:
				reply = wireMethod(60, 21, wireShort("test"))
			case class == 60 && method == 40:
				// Read actual content frames and verify the producer preserved persistence.
				_, _, content, err := wireRead(c)
				if fail(err) {
					return
				}
				if !bytes.Equal(content, wireHeader([]byte("payload"), amqp.Persistent)) {
					done <- fmt.Errorf("delivery metadata changed: %x", content)
					return
				}
				_, _, body, err := wireRead(c)
				if fail(err) {
					return
				}
				if string(body) != "payload" {
					done <- errors.New("body changed")
					return
				}
				if mode == "timeout" {
					continue
				}
				if mode == "return" {
					args := []byte{1, 56}
					args = append(args, wireShort("NO_ROUTE")...)
					args = append(args, wireShort("failed")...)
					args = append(args, wireShort("key")...)
					if fail(wireSend(c, 1, ch, wireMethod(60, 50, args))) {
						return
					}
					if fail(wireSend(c, 2, ch, wireHeader(body, amqp.Persistent))) {
						return
					}
					if fail(wireSend(c, 3, ch, body)) {
						return
					}
				}
				ack := make([]byte, 9)
				binary.BigEndian.PutUint64(ack, 1)
				id := uint16(80)
				if mode == "nack" {
					id = 120
				}
				if fail(wireSend(c, 1, ch, wireMethod(60, id, ack))) {
					return
				}
				continue
			case class == 60 && method == 80:
				acked.Store(true)
				done <- nil
				return
			}
			if reply != nil {
				if fail(wireSend(c, 1, ch, reply)) {
					return
				}
			}
		}
	}()
	return "amqp://guest:guest@" + l.Addr().String() + "/", acked, done
}
func TestRabbitNativeProtocolConfirmReturnNackAndTimeout(t *testing.T) {
	for _, mode := range []string{"ack", "return", "nack", "timeout"} {
		t.Run(mode, func(t *testing.T) {
			url, acked, done := startWireRabbit(t, mode)
			opts := reliabilityOptions()
			opts.OperationTimeout = time.Second
			opts.DeliveryTimeout = 50 * time.Millisecond
			cfg := &RabbitmqConfig{URL: url, ConsumerQueue: "source", FailExchange: "failed", PrefetchCount: 1, ConsumerCount: 1}
			rt := newRuntime(opts, func(context.Context, string, string, []byte) (bool, error) { return false, nil })
			defer rt.cancel()
			session, err := openRabbitSession(rt.ctx, cfg, opts)
			if err != nil {
				t.Fatal(err)
			}
			// Actual native Channel settlement needs the delivery's channel acknowledger.
			native := session.(*amqpSession)
			event := amqp.Delivery{Acknowledger: native.channel, DeliveryTag: 1, RoutingKey: "key", MessageId: "message-1", ContentType: "application/json", DeliveryMode: amqp.Persistent, Body: []byte("payload")}
			r := &RabbitmqConsumer{runtime: rt, quit: make(chan struct{})}
			err = r.handleDelivery(rt.ctx, cfg, session, event)
			session.Close()
			if mode == "ack" && err != nil {
				t.Fatal(err)
			}
			if mode != "ack" && err == nil {
				t.Fatal("unconfirmed publish considered success")
			}
			select {
			case peerErr := <-done:
				if peerErr != nil {
					t.Fatal(peerErr)
				}
			case <-time.After(2 * time.Second):
				t.Fatal("native peer did not finish")
			}
			if acked.Load() != (mode == "ack") {
				t.Fatalf("source Ack in %s mode=%v", mode, acked.Load())
			}
		})
	}
}
