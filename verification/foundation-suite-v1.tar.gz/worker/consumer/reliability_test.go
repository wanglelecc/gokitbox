package consumer

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
	amqp "github.com/rabbitmq/amqp091-go"
	"github.com/redis/go-redis/v9"
	"sync"
	"sync/atomic"
	"testing"
	"time"
)

func reliabilityOptions() RuntimeOptions {
	return RuntimeOptions{HandlerTimeout: 100 * time.Millisecond, RetryDelay: time.Millisecond, DeliveryTimeout: 30 * time.Millisecond, OperationTimeout: 100 * time.Millisecond}
}

type fakeKafkaSession struct {
	events                 []*kafka.Message
	reads, commits, closed atomic.Int32
	commitErr              error
	commitStarted          chan struct{}
	commitRelease          chan struct{}
}

func (f *fakeKafkaSession) ReadMessage(time.Duration) (*kafka.Message, error) {
	i := int(f.reads.Add(1)) - 1
	if i >= len(f.events) {
		return nil, errors.New("end of fixture")
	}
	return f.events[i], nil
}
func (f *fakeKafkaSession) CommitMessage(*kafka.Message) ([]kafka.TopicPartition, error) {
	f.commits.Add(1)
	if f.commitStarted != nil {
		close(f.commitStarted)
		<-f.commitRelease
	}
	return nil, f.commitErr
}
func (f *fakeKafkaSession) Close() error { f.closed.Add(1); return nil }

type rejectingFailureProducer struct{}

func (rejectingFailureProducer) Produce(*kafka.Message, chan kafka.Event) error {
	return errors.New("DLQ unavailable")
}
func (rejectingFailureProducer) Flush(int) int { return 0 }
func (rejectingFailureProducer) Close()        {}
func testKafka(t *testing.T, session *fakeKafkaSession, callback ContextConsumeCallback) *KafkaConsumer {
	t.Helper()
	return &KafkaConsumer{runtime: newRuntime(reliabilityOptions(), callback), quit: make(chan struct{}), wg: &sync.WaitGroup{}, producers: map[kafkaConnection]kafkaFailureProducer{}, sessionFactory: func(*KafkaConfig) (kafkaSession, error) { return session, nil }}
}
func TestKafkaFailureTransferCannotAdvanceOffset(t *testing.T) {
	topic := "source"
	cfg := &KafkaConfig{Host: []string{"fake"}, Topic: topic, FailTopic: "failed"}
	session := &fakeKafkaSession{events: []*kafka.Message{{TopicPartition: kafka.TopicPartition{Topic: &topic, Offset: 100}, Value: []byte("bad")}, {TopicPartition: kafka.TopicPartition{Topic: &topic, Offset: 101}, Value: []byte("good")}}}
	k := testKafka(t, session, func(context.Context, string, string, []byte) (bool, error) {
		return false, errors.New("business failure")
	})
	defer k.runtime.cancel()
	k.producers[kafkaResourceKey(cfg)] = rejectingFailureProducer{}
	if k.doConsume(k.runtime.ctx, cfg, newBackoff(time.Millisecond, time.Second)) {
		t.Fatal("unresolved message reported clean")
	}
	if session.reads.Load() != 1 || session.commits.Load() != 0 || session.closed.Load() != 1 {
		t.Fatalf("offset crossed failed message: reads=%d commits=%d closed=%d", session.reads.Load(), session.commits.Load(), session.closed.Load())
	}
}
func TestKafkaCommitFailureCannotReadLaterMessage(t *testing.T) {
	session := &fakeKafkaSession{events: []*kafka.Message{{Value: []byte("one")}, {Value: []byte("two")}}, commitErr: errors.New("commit unavailable")}
	k := testKafka(t, session, func(context.Context, string, string, []byte) (bool, error) { return true, nil })
	defer k.runtime.cancel()
	k.doConsume(k.runtime.ctx, &KafkaConfig{Topic: "source"}, newBackoff(time.Millisecond, time.Second))
	if session.reads.Load() != 1 || session.commits.Load() != 3 {
		t.Fatal("advanced after commit failure")
	}
}
func TestKafkaCommitTimeoutJoinsNativeCallBeforeClose(t *testing.T) {
	session := &fakeKafkaSession{events: []*kafka.Message{{Value: []byte("one")}}, commitStarted: make(chan struct{}), commitRelease: make(chan struct{})}
	k := testKafka(t, session, func(context.Context, string, string, []byte) (bool, error) { return true, nil })
	k.wg.Add(1)
	go func() {
		defer k.wg.Done()
		k.doConsume(k.runtime.ctx, &KafkaConfig{Topic: "source"}, newBackoff(time.Millisecond, time.Second))
	}()
	<-session.commitStarted
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := k.CloseContext(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	if session.closed.Load() != 0 {
		t.Fatal("closed native client while commit still owns it")
	}
	close(session.commitRelease)
	if err := k.CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
	if session.closed.Load() != 1 || session.reads.Load() != 1 {
		t.Fatal("native ownership or barrier broken")
	}
}
func TestAtomicDelayPopUnderConcurrency(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	const count = 100
	for i := 0; i < count; i++ {
		if err := client.ZAdd(ctx, "due", redis.Z{Score: 1, Member: fmt.Sprint(i)}).Err(); err != nil {
			t.Fatal(err)
		}
	}
	client.ZAdd(ctx, "due", redis.Z{Score: float64(time.Now().Unix() + 3600), Member: "future"})
	var wg sync.WaitGroup
	var seen sync.Map
	var duplicate atomic.Bool
	for i := 0; i < 16; i++ {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for {
				m, err := (&DelayConsumer{}).pop(ctx, client, "due", time.Now().Unix())
				if errors.Is(err, redis.Nil) {
					return
				}
				if err != nil {
					t.Error(err)
					return
				}
				if _, loaded := seen.LoadOrStore(m, true); loaded {
					duplicate.Store(true)
				}
			}
		}()
	}
	wg.Wait()
	got := 0
	seen.Range(func(_, _ any) bool { got++; return true })
	if duplicate.Load() || got != count || client.ZCard(ctx, "due").Val() != 1 {
		t.Fatalf("bad atomic dequeue: duplicate=%v count=%d", duplicate.Load(), got)
	}
}
func TestLegacyRedisFailureQueueOutageRestoresSource(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	client.RPush(ctx, "source", "job")
	client.Set(ctx, "failed", "wrong-type", 0)
	cfg := &RedisConfig{DeliveryMode: "legacy", Queue: "source", FailQueue: "failed", FailCount: 0}
	r := &RedisConsumer{runtime: newRuntime(reliabilityOptions(), func(context.Context, string, string, []byte) (bool, error) { return false, errors.New("business") }), quit: make(chan struct{})}
	defer r.runtime.cancel()
	r.doConsume(r.runtime.ctx, client, cfg, newBackoff(time.Millisecond, time.Second))
	values, err := client.LRange(ctx, "source", 0, -1).Result()
	if err != nil || len(values) != 1 || values[0] != "job" {
		t.Fatalf("legacy message lost: %v %v", values, err)
	}
}
func TestLegacyDelayCancellationPreservesNewSchedule(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	client.ZAdd(ctx, "source", redis.Z{Score: 1, Member: "job"})
	entered := make(chan struct{})
	rt := newRuntime(reliabilityOptions(), func(ctx context.Context, _ string, _ string, _ []byte) (bool, error) {
		close(entered)
		<-ctx.Done()
		return false, ctx.Err()
	})
	d := &DelayConsumer{runtime: rt, quit: make(chan struct{})}
	done := make(chan bool, 1)
	go func() {
		done <- d.doConsume(rt.ctx, client, &DelayConfig{DeliveryMode: "legacy", Queue: "source"}, newBackoff(time.Millisecond, time.Second))
	}()
	<-entered
	future := float64(time.Now().Unix() + 3600)
	client.ZAdd(ctx, "source", redis.Z{Score: future, Member: "job"})
	close(d.quit)
	rt.cancel()
	<-done
	if got := client.ZScore(ctx, "source", "job").Val(); got != future {
		t.Fatal("shutdown restoration overwrote a newer schedule")
	}
}

type fakeRabbitSession struct {
	publishErr, settleErr      error
	published, acked, rejected int
	requeue                    bool
	copy                       amqp.Delivery
}

func (f *fakeRabbitSession) deliveries() <-chan amqp.Delivery { return nil }
func (f *fakeRabbitSession) transferFailure(_ context.Context, _ string, event amqp.Delivery) error {
	f.published++
	f.copy = event
	return f.publishErr
}
func (f *fakeRabbitSession) settle(_ context.Context, _ amqp.Delivery, reject, requeue bool) error {
	if reject {
		f.rejected++
		f.requeue = requeue
	} else {
		f.acked++
	}
	return f.settleErr
}
func (f *fakeRabbitSession) Close() error { return nil }
func TestRabbitFailureMustBeConfirmedBeforeSourceAck(t *testing.T) {
	for _, failure := range []error{errors.New("unroutable"), errors.New("nacked"), context.DeadlineExceeded, nil} {
		r := &RabbitmqConsumer{runtime: newRuntime(reliabilityOptions(), func(context.Context, string, string, []byte) (bool, error) { return false, nil }), quit: make(chan struct{})}
		session := &fakeRabbitSession{publishErr: failure}
		err := r.handleDelivery(r.runtime.ctx, &RabbitmqConfig{FailExchange: "failed"}, session, amqp.Delivery{MessageId: "id", DeliveryMode: amqp.Persistent, Body: []byte("payload")})
		if failure != nil && (err == nil || session.acked != 0 || session.rejected != 0) {
			t.Fatal("unconfirmed source settled")
		}
		if failure == nil && (err != nil || session.acked != 1) {
			t.Fatal("confirmed transfer not acknowledged")
		}
		r.runtime.cancel()
	}
}

func TestConfigSnapshotsAndBudgets(t *testing.T) {
	base := &Configure{Enabled: &ConsumeEnabled{Kafka: true}, Kafka: []*KafkaConfig{{Host: []string{"one"}, Topic: "topic", ConsumerGroup: "group", ConsumerCount: 1, SASL: &SASL{Enabled: true, User: "user", Password: "test"}}}}
	copy := base.Snapshot()
	base.Kafka[0].Host[0] = "changed"
	base.Kafka[0].SASL.User = "changed"
	base.Enabled.Kafka = false
	if !copy.Enabled.Kafka || copy.Kafka[0].Host[0] != "one" || copy.Kafka[0].SASL.User != "user" {
		t.Fatal("caller mutation crossed snapshot")
	}
	for _, options := range []RuntimeOptions{{HandlerTimeout: -1}, {OperationTimeout: time.Nanosecond}, {MaxPollInterval: time.Second}, {HandlerTimeout: time.Hour}} {
		c := copy.Snapshot()
		c.Runtime = options
		if err := c.Validate(); err == nil {
			t.Fatal("invalid effective budgets accepted", options)
		}
	}
	if err := copy.Validate(); err != nil {
		t.Fatal(err)
	}
	for _, test := range []func() error{
		func() error {
			_, err := NewRedisConsumer([]*RedisConfig{nil}, func(string, string, []byte) bool { return true }, nil)
			return err
		},
		func() error {
			_, err := NewDelayConsumer([]*DelayConfig{{Addr: "local", Queue: "q", ConsumerCount: 1}}, nil, nil)
			return err
		},
		func() error {
			_, err := NewRabbitmqConsumer([]*RabbitmqConfig{nil}, func(string, string, []byte) bool { return true }, nil)
			return err
		},
	} {
		if err := test(); err == nil {
			t.Fatal("invalid constructor accepted")
		}
	}
}
func TestRuntimeJSONDurations(t *testing.T) {
	var o RuntimeOptions
	if err := json.Unmarshal([]byte(`{"handlerTimeout":"2s","retryDelay":1000000}`), &o); err != nil {
		t.Fatal(err)
	}
	if o.HandlerTimeout != 2*time.Second || o.RetryDelay != time.Millisecond {
		t.Fatal(o)
	}
	if err := json.Unmarshal([]byte(`{"handlerTimout":"2s"}`), &o); err == nil {
		t.Fatal("unknown runtime option accepted")
	}
}

func TestHandlerMutationCannotCorruptFailurePayload(t *testing.T) {
	original := []byte("original")
	rt := newRuntime(reliabilityOptions(), func(_ context.Context, _ string, _ string, payload []byte) (bool, error) {
		payload[0] = 'X'
		return false, errors.New("failed after mutation")
	})
	defer rt.cancel()
	for attempt := 0; attempt < 2; attempt++ {
		if rt.call(rt.ctx, nil, "handler", "source", original) {
			t.Fatal("failed mutation acknowledged")
		}
	}
	if string(original) != "original" {
		t.Fatal("retry/DLQ bytes changed by handler")
	}
}

func TestLegacyRestoreFailureIsVisibleInCloseResult(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	if err := client.RPush(ctx, "source", "owned").Err(); err != nil {
		t.Fatal(err)
	}
	injected := errors.New("injected persistence failure")
	client.AddHook(reviewRedisHook{process: func(next redis.ProcessHook) redis.ProcessHook {
		return func(ctx context.Context, cmd redis.Cmder) error {
			if cmd.Name() == "rpush" {
				return injected
			}
			return next(ctx, cmd)
		}
	}})
	r := &RedisConsumer{runtime: newRuntime(reliabilityOptions(), func(context.Context, string, string, []byte) (bool, error) { return false, nil }), quit: make(chan struct{}), wg: &sync.WaitGroup{}}
	r.doConsume(r.runtime.ctx, client, &RedisConfig{DeliveryMode: "legacy", Queue: "source", FailQueue: "failed"}, newBackoff(time.Millisecond, time.Second))
	if err := r.CloseContext(ctx); !errors.Is(err, injected) {
		t.Fatalf("restore failure hidden by close: %v", err)
	}
}
func TestHandlerDeadlineCannotAcknowledgeSuccess(t *testing.T) {
	options := reliabilityOptions()
	options.HandlerTimeout = 20 * time.Millisecond
	rt := newRuntime(options, func(ctx context.Context, _ string, _ string, _ []byte) (bool, error) { <-ctx.Done(); return true, nil })
	defer rt.cancel()
	before := time.Now()
	if rt.call(rt.ctx, nil, "handler", "source", nil) {
		t.Fatal("expired handler acknowledged")
	}
	if elapsed := time.Since(before); elapsed > time.Second {
		t.Fatal("handler deadline not respected", elapsed)
	}
}
