package consumer

import (
	"context"
	"errors"
	"github.com/confluentinc/confluent-kafka-go/v2/kafka"
	"net"
	"os/exec"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/redis/go-redis/v9"
)

type reviewRedisHook struct {
	process func(redis.ProcessHook) redis.ProcessHook
}

func (h reviewRedisHook) DialHook(next redis.DialHook) redis.DialHook { return next }
func (h reviewRedisHook) ProcessHook(next redis.ProcessHook) redis.ProcessHook {
	return h.process(next)
}
func (h reviewRedisHook) ProcessPipelineHook(next redis.ProcessPipelineHook) redis.ProcessPipelineHook {
	return next
}
func reviewRedis(t *testing.T) *redis.Client {
	t.Helper()
	if _, err := exec.LookPath("redis-server"); err != nil {
		t.Skip("redis-server unavailable")
	}
	// Keep the Unix socket path short enough for macOS sockaddr_un.
	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}
	addr := listener.Addr().String()
	listener.Close()
	_, port, _ := net.SplitHostPort(addr)
	cmd := exec.Command("redis-server", "--bind", "127.0.0.1", "--port", port, "--save", "", "--appendonly", "no", "--dir", filepath.Clean(t.TempDir()))
	if err = cmd.Start(); err != nil {
		t.Fatal(err)
	}
	client := redis.NewClient(&redis.Options{Addr: addr, MaxRetries: -1})
	t.Cleanup(func() { client.Close(); cmd.Process.Kill(); cmd.Wait() })
	deadline := time.Now().Add(3 * time.Second)
	for client.Ping(context.Background()).Err() != nil {
		if time.Now().After(deadline) {
			t.Fatal("isolated Redis did not start")
		}
		time.Sleep(10 * time.Millisecond)
	}
	return client
}
func TestDelayLeavesFutureMemberWithoutReinsert(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	if err := client.ZAdd(ctx, "future", redis.Z{Score: float64(time.Now().Unix() + 3600), Member: "message"}).Err(); err != nil {
		t.Fatal(err)
	}
	client.AddHook(reviewRedisHook{process: func(next redis.ProcessHook) redis.ProcessHook {
		return func(ctx context.Context, cmd redis.Cmder) error {
			if cmd.Name() == "zadd" {
				return errors.New("injected reinsert failure")
			}
			return next(ctx, cmd)
		}
	}})
	_, err := (&DelayConsumer{}).pop(ctx, client, "future", time.Now().Unix())
	if !errors.Is(err, redis.Nil) {
		t.Fatal(err)
	}
	if n := client.ZCard(ctx, "future").Val(); n != 1 {
		t.Fatal("future member lost")
	}
}
func TestDelayPopPreservesConcurrentReschedule(t *testing.T) {
	client := reviewRedis(t)
	ctx := context.Background()
	old := float64(time.Now().Unix() + 3600)
	newer := old + 3600
	if err := client.ZAdd(ctx, "future", redis.Z{Score: old, Member: "message"}).Err(); err != nil {
		t.Fatal(err)
	}
	writer := redis.NewClient(client.Options())
	defer writer.Close()
	client.AddHook(reviewRedisHook{process: func(next redis.ProcessHook) redis.ProcessHook {
		return func(ctx context.Context, cmd redis.Cmder) error {
			if cmd.Name() == "eval" {
				if err := writer.ZAdd(ctx, "future", redis.Z{Score: newer, Member: "message"}).Err(); err != nil {
					return err
				}
			}
			return next(ctx, cmd)
		}
	}})
	_, err := (&DelayConsumer{}).pop(ctx, client, "future", time.Now().Unix())
	if !errors.Is(err, redis.Nil) {
		t.Fatal(err)
	}
	if got := client.ZScore(ctx, "future", "message").Val(); got != newer {
		t.Fatalf("reschedule overwritten, score %v", got)
	}
}

type reviewBlockedFailureProducer struct {
	ready    chan struct{}
	delivery chan kafka.Event
}

func (p *reviewBlockedFailureProducer) Produce(_ *kafka.Message, ch chan kafka.Event) error {
	p.delivery = ch
	close(p.ready)
	return nil
}
func (p *reviewBlockedFailureProducer) Flush(int) int { return 0 }
func (p *reviewBlockedFailureProducer) Close()        {}
func TestKafkaDeliveryWaitCancelsOnShutdownDeadline(t *testing.T) {
	cfg := &KafkaConfig{Host: []string{"isolated-fake"}, FailTopic: "failed"}
	p := &reviewBlockedFailureProducer{ready: make(chan struct{})}
	rt := newRuntime(RuntimeOptions{DeliveryTimeout: time.Second}, func(context.Context, string, string, []byte) (bool, error) { return false, nil })
	k := &KafkaConsumer{runtime: rt, quit: make(chan struct{}), wg: &sync.WaitGroup{}, producers: map[kafkaConnection]kafkaFailureProducer{kafkaResourceKey(cfg): p}}
	k.wg.Add(1)
	done := make(chan error, 1)
	go func() { defer k.wg.Done(); done <- k.sendByHashPartition(cfg, "failed", []byte("body"), nil) }()
	<-p.ready
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	k.CloseContext(ctx)
	select {
	case err := <-done:
		if !errors.Is(err, context.Canceled) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("delivery wait ignored shutdown deadline")
	}
	p.delivery <- &kafka.Message{}
	if err := k.CloseContext(context.Background()); err != nil {
		t.Fatal(err)
	}
}
