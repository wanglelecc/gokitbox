package worker

import (
	"context"
	"errors"
	"testing"
)

func TestStartFailureAndPartialStop(t *testing.T) {
	w := NewWorker()
	failure := errors.New("consumer initialization failed")
	w.AddBeforeServerStartFunc(func() error { return failure })
	if err := w.Start(context.Background()); !errors.Is(err, failure) {
		t.Fatal(err)
	}
	if err := w.Stop(context.Background()); err != nil {
		t.Fatal(err)
	}
	if err := w.Wait(); err != nil {
		t.Fatal(err)
	}
	if err := w.Stop(context.Background()); err != nil {
		t.Fatal(err)
	}
}
