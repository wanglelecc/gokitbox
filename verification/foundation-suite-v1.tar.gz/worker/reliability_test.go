package worker

import (
	"context"
	"errors"
	"github.com/wanglelecc/gokitbox/worker/consumer"
	"sync"
	"sync/atomic"
	"syscall"
	"testing"
	"time"
)

func TestConcurrentStartStopAndAfterHooksExactlyOnce(t *testing.T) {
	for i := 0; i < 40; i++ {
		w := NewWorker()
		var after atomic.Int32
		w.AddBeforeServerStartFunc(w.InitConsumerWithConfig(&consumer.Configure{Enabled: &consumer.ConsumeEnabled{}}))
		w.AddAfterServerStopFunc(func() { after.Add(1) })
		started := make(chan error, 1)
		go func() { started <- w.Start(context.Background()) }()
		var wg sync.WaitGroup
		for n := 0; n < 4; n++ {
			wg.Add(1)
			go func() {
				defer wg.Done()
				ctx, cancel := context.WithTimeout(context.Background(), time.Second)
				defer cancel()
				if err := w.Stop(ctx); err != nil {
					t.Error(err)
				}
			}()
		}
		wg.Wait()
		<-started
		if err := w.Wait(); err != nil {
			t.Fatal(err)
		}
		expected := int32(0)
		w.mu.Lock()
		if w.started {
			expected = 1
		}
		w.mu.Unlock()
		if after.Load() != expected {
			t.Fatal("stop hooks not exactly once")
		}
	}
}
func TestWorkerHandlerMapsAreIsolated(t *testing.T) {
	a, b := NewWorker(), NewWorker()
	handles := map[string]Handle{"same": func(context.Context, []byte) (bool, error) { return true, nil }}
	initA := a.RegisterHandle(handles)
	handles["same"] = nil
	if err := initA(); err != nil {
		t.Fatal(err)
	}
	if err := b.RegisterHandle(map[string]Handle{"same": func(context.Context, []byte) (bool, error) { return false, errors.New("different worker") }})(); err != nil {
		t.Fatal(err)
	}
	if !a.deal("same", "source", nil) || b.deal("same", "source", nil) {
		t.Fatal("instance handler registry leaked")
	}
	if err := a.RegisterHandle(map[string]Handle{"invalid": nil})(); err == nil {
		t.Fatal("nil handler accepted")
	}
}
func TestServeCanBeStoppedThroughLifecycle(t *testing.T) {
	w := NewWorker()
	entered := make(chan struct{})
	w.AddBeforeServerStartFunc(func() error { close(entered); return nil })
	done := make(chan error, 1)
	go func() { done <- w.Serve() }()
	<-entered
	ctx, cancel := context.WithTimeout(context.Background(), time.Second)
	defer cancel()
	if err := w.Stop(ctx); err != nil {
		t.Fatal(err)
	}
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-ctx.Done():
		t.Fatal("Serve still waits for process signal after Stop")
	}
}

func TestServeObservesSignalDuringStartup(t *testing.T) {
	w := NewWorker().SetShutdownTimeout(30 * time.Millisecond)
	entered, release := make(chan struct{}), make(chan struct{})
	w.AddBeforeServerStartFunc(func() error { close(entered); <-release; return nil })
	served := make(chan error, 1)
	go func() { served <- w.Serve() }()
	<-entered
	w.exit <- syscall.SIGTERM
	select {
	case err := <-served:
		if !errors.Is(err, context.DeadlineExceeded) {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("Serve ignored signal during startup")
	}
	close(release)
	done := make(chan error, 1)
	go func() { done <- w.Wait() }()
	select {
	case err := <-done:
		if err != nil {
			t.Fatal(err)
		}
	case <-time.After(time.Second):
		t.Fatal("startup cleanup did not finish")
	}
}
