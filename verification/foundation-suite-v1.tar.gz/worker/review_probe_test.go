package worker

import (
	"context"
	"errors"
	"testing"
	"time"
)

// Regression assertions for previously reproduced Worker defects.
func TestHandlerErrorFailsAndTraceIsVisible(t *testing.T) {
	const name = "review-probe-handler"
	handleLock.Lock()
	old, had := handleMap[name]
	handleLock.Unlock()
	t.Cleanup(func() {
		handleLock.Lock()
		defer handleLock.Unlock()
		if had {
			handleMap[name] = old
		} else {
			delete(handleMap, name)
		}
	})
	w := NewWorker()
	var received context.Context
	RegisterHandle(name, func(ctx context.Context, _ []byte) (bool, error) {
		received = ctx
		return true, errors.New("business failure")
	})
	if w.deal(name, "topic", []byte(`{"trace_id":"expected-trace"}`)) {
		t.Fatal("handler error was acknowledged")
	}
	if received.Value("trace_id") != "expected-trace" {
		t.Fatal("trace unavailable to logger")
	}

}
func TestStopWaitsForStartupToStopCreatingResources(t *testing.T) {
	w := NewWorker()
	entered, release := make(chan struct{}), make(chan struct{})
	started := make(chan error, 1)
	w.AddBeforeServerStartFunc(func() error { close(entered); <-release; return nil })
	go func() { started <- w.Start(context.Background()) }()
	<-entered
	ctx, cancel := context.WithTimeout(context.Background(), 20*time.Millisecond)
	defer cancel()
	if err := w.Stop(ctx); !errors.Is(err, context.DeadlineExceeded) {
		t.Fatal(err)
	}
	finished := make(chan error, 1)
	go func() { finished <- w.Wait() }()
	select {
	case <-finished:
		t.Fatal("Wait succeeded before start hook exited")
	default:
	}
	close(release)
	if err := <-started; !errors.Is(err, context.Canceled) {
		t.Fatal(err)
	}
	if err := <-finished; err != nil {
		t.Fatal(err)
	}
}
